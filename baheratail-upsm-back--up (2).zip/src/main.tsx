import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initCentralizedErrorLogging } from './utils/errorHandler';

// Initialize global error catching and Firebase audit logging
initCentralizedErrorLogging();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

