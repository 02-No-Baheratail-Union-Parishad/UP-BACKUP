import React, { useState, useEffect } from 'react';
import { SupportTicket, AiAnalyticsForecast, GeneratedCertificateRecord } from '../types';
import { TrendingUp, MessageSquare, Languages, Sparkles, Send, CheckCircle2, Clock, AlertCircle, RefreshCw, BarChart3, HelpCircle, FileText } from 'lucide-react';

interface AiAnalyticsSupportHubProps {
  records: GeneratedCertificateRecord[];
}

export const AiAnalyticsSupportHub: React.FC<AiAnalyticsSupportHubProps> = ({ records }) => {
  const [activeSubTab, setActiveSubTab] = useState<'analytics' | 'tickets' | 'translation'>('analytics');

  // AI Analytics & Forecast State
  const [forecastData, setForecastData] = useState<AiAnalyticsForecast | null>(null);
  const [isLoadingForecast, setIsLoadingForecast] = useState(false);

  // Support Tickets State
  const [tickets, setTickets] = useState<SupportTicket[]>([
    {
      id: 'TCK-101',
      citizenName: 'মো: শফিকুল ইসলাম',
      phone: '01712345678',
      nidNumber: '19929318456000789',
      subject: 'নাগরিকত্ব সনদে মাতার নামের ভুল সংশোধন',
      description: 'আমার এনআইডি অনুযায়ী মায়ের নাম "আলেয়া বেগম" কিন্তু প্রত্যয়নপত্রে "আলেয়া খাতুন" চলে এসেছে। সংশোধন চাই।',
      category: 'সনদ সংশোধন',
      status: 'নতুন',
      priority: 'জরুরি',
      aiSuggestedReply: 'প্রিয় আবেদনকারী, আপনার NID এর কপি সংযুক্ত করে ইউনিয়ন ডিজিটাল সেন্টারে যোগাযোগ করুন। ইউডিসি উদ্যোক্তা সংশোধিত সনদ প্রস্তুত করে চেয়ারম্যান মহোদয়ের স্বাক্ষরের জন্য প্রস্তুত করবেন।',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'TCK-102',
      citizenName: 'মোছা: নাসরিন আক্তার',
      phone: '01898765432',
      nidNumber: '19989318456000456',
      subject: 'বাৎসরিক আয় সনদ আবেদনের সময়কাল',
      description: 'কৃষি ঋণের জন্য আয় সনদ প্রয়োজন। আবেদন করার পর কত দিনের মধ্যে ইউপি কার্যালয় থেকে মূল কপি পাওয়া যাবে?',
      category: 'সাধারণ অনুসন্ধান',
      status: 'প্রক্রিয়াধীন',
      priority: 'সাধারণ',
      aiSuggestedReply: 'প্রিয় আবেদনকারী, অনলাইন আবেদনের পর ১ কর্মদিবসের মধ্যে ইউডিসি উদ্যোক্তা কর্তৃক যাচাইপূর্বক সিল ও স্বাক্ষরযুক্ত মূল কপি সরবরাহ করা হয়।',
      createdAt: new Date(Date.now() - 86400000).toISOString(),
    },
  ]);

  const [newCitizenName, setNewCitizenName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newNid, setNewNid] = useState('');
  const [newSubject, setNewSubject] = useState('');
  const [newCategory, setNewCategory] = useState<SupportTicket['category']>('সনদ সংশোধন');
  const [newDesc, setNewDesc] = useState('');
  const [isSubmittingTicket, setIsSubmittingTicket] = useState(false);

  // Translation State
  const [transInputName, setTransInputName] = useState('মো: আল আমিন');
  const [transInputVillage, setTransInputVillage] = useState('বহেড়াতৈল');
  const [transInputCertType, setTransInputCertType] = useState('নাগরিকত্ব সনদ');
  const [transInputBody, setTransInputBody] = useState(
    'এই মর্মে প্রত্যয়ন করা যাচ্ছে যে, মো: আল আমিন ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের বহেড়াতৈল গ্রামের একজন স্থায়ী বাসিন্দা। তিনি জন্মসূত্রে বাংলাদেশের নাগরিক এবং তাহার নৈতিক চরিত্র সন্তোষজনক।'
  );
  const [translatedText, setTranslatedText] = useState<string | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);

  // Load forecast on mount
  useEffect(() => {
    fetchForecast();
  }, [records.length]);

  const fetchForecast = async () => {
    setIsLoadingForecast(true);
    try {
      const res = await fetch('/api/analytics-forecast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recentRecordCount: Math.max(records.length, 142) }),
      });
      const data = await res.json();
      if (data.success && data.forecast) {
        setForecastData(data.forecast);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingForecast(false);
    }
  };

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCitizenName || !newSubject || !newDesc) return;

    setIsSubmittingTicket(true);
    const tempTicket: SupportTicket = {
      id: `TCK-${Math.floor(100 + Math.random() * 900)}`,
      citizenName: newCitizenName,
      phone: newPhone || '01700000000',
      nidNumber: newNid || '19900000000000000',
      subject: newSubject,
      description: newDesc,
      category: newCategory,
      status: 'নতুন',
      priority: 'সাধারণ',
      createdAt: new Date().toISOString(),
    };

    try {
      const res = await fetch('/api/support-ticket-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ticket: tempTicket }),
      });
      const data = await res.json();
      if (data.success && data.result) {
        tempTicket.priority = data.result.priority || 'সাধারণ';
        tempTicket.aiSuggestedReply = data.result.aiSuggestedReply;
      }
    } catch (e) {
      console.error(e);
    } finally {
      setTickets([tempTicket, ...tickets]);
      setNewCitizenName('');
      setNewPhone('');
      setNewNid('');
      setNewSubject('');
      setNewDesc('');
      setIsSubmittingTicket(false);
    }
  };

  const handleTranslate = async () => {
    if (!transInputBody) return;
    setIsTranslating(true);
    try {
      const res = await fetch('/api/translate-certificate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          certificateBody: transInputBody,
          certType: transInputCertType,
          applicantName: transInputName,
          village: transInputVillage,
        }),
      });
      const data = await res.json();
      if (data.success && data.translatedText) {
        setTranslatedText(data.translatedText);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsTranslating(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 rounded-2xl p-6 text-white shadow-lg border border-emerald-700">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-emerald-400" />
              <h2 className="text-xl font-bold font-serif">
                AI অ্যানালিটিক্স, ই-সার্ভিস পূর্বাভাস ও নাগরিক সহায়তা হেল্পডেস্ক
              </h2>
            </div>
            <p className="text-xs text-emerald-200 mt-1">
              Gemini AI-চালিত কর্মপরিকল্পনা, চাহিদা পূর্বাভাস, স্বয়ংক্রিয় নাগরিক টিকেট রেসপন্স ও দ্বিমুখী ব্যাকরণগত ইংরেজি অনুবাদ মডিউল।
            </p>
          </div>

          <div className="flex bg-emerald-950/80 p-1 rounded-xl border border-emerald-700/60">
            <button
              onClick={() => setActiveSubTab('analytics')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeSubTab === 'analytics'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-emerald-300 hover:text-white'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>পূর্বাভাস</span>
            </button>
            <button
              onClick={() => setActiveSubTab('tickets')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeSubTab === 'tickets'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-emerald-300 hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>হেল্পডেস্ক ({tickets.length})</span>
            </button>
            <button
              onClick={() => setActiveSubTab('translation')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeSubTab === 'translation'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-emerald-300 hover:text-white'
              }`}
            >
              <Languages className="w-3.5 h-3.5" />
              <span>ইংরেজি অনুবাদ</span>
            </button>
          </div>
        </div>
      </div>

      {/* SUB-TAB 1: ANALYTICS & FORECAST */}
      {activeSubTab === 'analytics' && (
        <div className="space-y-6">
          
          <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-emerald-700" />
              <h3 className="text-sm font-bold text-gray-800">
                ই-গর্ভন্যান্স ওয়ার্কলোড ও সনদপত্র ইস্যু AI পূর্বাভাস (Monthly Trend)
              </h3>
            </div>
            <button
              onClick={fetchForecast}
              disabled={isLoadingForecast}
              className="text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-xl border border-emerald-200 transition flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingForecast ? 'animate-spin' : ''}`} />
              <span>রিফ্রেশ করুন</span>
            </button>
          </div>

          {forecastData && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Stat Card 1 */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
                <span className="text-xs font-bold text-gray-500 block">চলতি মাসে মোট ইস্যুকৃত সনদ:</span>
                <span className="text-3xl font-extrabold text-emerald-800 font-mono">
                  {forecastData.totalCertificatesThisMonth} টি
                </span>
                <p className="text-[11px] text-gray-500">ইউডিি রেজিস্ট্রি ও গুগল ডক্স লাইভ রিয়েল-টাইম তথ্য</p>
              </div>

              {/* Stat Card 2 */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
                <span className="text-xs font-bold text-gray-500 block">আগামী মাসের AI পূর্বাভাসিত আবেদন:</span>
                <span className="text-3xl font-extrabold text-teal-800 font-mono">
                  ~{forecastData.projectedNextMonth} টি
                </span>
                <p className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" />
                  আনুমানিক ২৩% বৃদ্ধির সম্ভাবনা
                </p>
              </div>

              {/* Stat Card 3 */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
                <span className="text-xs font-bold text-gray-500 block">সর্বোচ্চ চাহিদা এলাকা:</span>
                <span className="text-base font-bold text-slate-800 block">
                  {forecastData.peakWards[0]?.wardNo || 'ওয়ার্ড ০২ (বহেড়াতৈল)'}
                </span>
                <p className="text-[11px] text-gray-500">কৃষি প্রণোদনা ও শিক্ষা উপবৃত্তি প্রদান মৌসুম</p>
              </div>

            </div>
          )}

          {/* Detailed Forecast & Insights */}
          {forecastData && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              
              <div className="md:col-span-7 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider flex items-center gap-1.5 border-b pb-2">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>Gemini AI প্রশাসনিক পূর্বাভাস সারসংক্ষেপ:</span>
                </h4>
                <p className="text-xs text-gray-800 leading-relaxed bg-emerald-50/50 p-3.5 rounded-xl border border-emerald-100 font-medium">
                  {forecastData.aiForecastSummary}
                </p>

                <h5 className="text-xs font-bold text-gray-700 uppercase tracking-wider pt-2">সুপারিশকৃত সার্ভিস অপটিমাইজেশন টিপস:</h5>
                <ul className="space-y-2">
                  {forecastData.resourceOptimizationTips.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs text-gray-700 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="md:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider border-b pb-2">
                  সনদপত্রের ধরন অনুযায়ী শতকরা হার:
                </h4>
                <div className="space-y-3">
                  {forecastData.popularTypes.map((item, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-xs font-semibold">
                        <span className="text-gray-800">{item.type}</span>
                        <span className="text-emerald-800 font-bold">{item.percentage}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-700 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${item.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

        </div>
      )}

      {/* SUB-TAB 2: SUPPORT TICKETS & AI ASSISTANT */}
      {activeSubTab === 'tickets' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Form: Submit New Support Ticket */}
          <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-gray-900 flex items-center gap-2 border-b pb-3">
              <HelpCircle className="w-4 h-4 text-emerald-700" />
              <span>নতুন নাগরিক সাহায্য টিকেট দাখিল করুন</span>
            </h3>

            <form onSubmit={handleCreateTicket} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-gray-700 block mb-1">নাগরিকের নাম:</label>
                <input
                  type="text"
                  required
                  value={newCitizenName}
                  onChange={(e) => setNewCitizenName(e.target.value)}
                  placeholder="যেমন: মো: রফিকুল ইসলাম"
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-semibold text-gray-700 block mb-1">মোবাইল নম্বর:</label>
                  <input
                    type="text"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    placeholder="017xxxxxxxx"
                    className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-700 block mb-1">ক্যাটাগরি:</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="সনদ সংশোধন">সনদ সংশোধন</option>
                    <option value="স্ট্যাটাস চেক">স্ট্যাটাস চেক</option>
                    <option value="কারিগরি সমস্যা">কারিগরি সমস্যা</option>
                    <option value="সাধারণ অনুসন্ধান">সাধারণ অনুসন্ধান</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-700 block mb-1">টিকিটের বিষয়:</label>
                <input
                  type="text"
                  required
                  value={newSubject}
                  onChange={(e) => setNewSubject(e.target.value)}
                  placeholder="যেমন: ওয়ারিশান বিবরণী স্মারক মিলছে না"
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-700 block mb-1">বিস্তারিত বিবরণ:</label>
                <textarea
                  rows={3}
                  required
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="সমস্যার বিস্তারিত লিখুন..."
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={isSubmittingTicket}
                className="w-full py-2.5 px-4 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
              >
                {isSubmittingTicket ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-emerald-300" />
                ) : (
                  <Send className="w-4 h-4 text-emerald-300" />
                )}
                <span>টিকিট দাখিল করুন & Gemini AI অটো রিপ্লাই নিন</span>
              </button>
            </form>
          </div>

          {/* List: Support Tickets with AI Suggested Reply */}
          <div className="lg:col-span-7 space-y-4">
            <h3 className="text-sm font-bold text-gray-900 flex items-center justify-between border-b pb-3">
              <span className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-700" />
                <span>সক্রিয় নাগরিক সহায়তা টিকেট রেজিস্ট্রি</span>
              </span>
              <span className="text-xs text-gray-500">মোট: {tickets.length} টি</span>
            </h3>

            <div className="space-y-4">
              {tickets.map((t) => (
                <div key={t.id} className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[11px] font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        {t.id}
                      </span>
                      <h4 className="text-xs font-bold text-gray-900 mt-1">{t.subject}</h4>
                      <p className="text-[11px] text-gray-500">
                        আবেদনকারী: <strong>{t.citizenName}</strong> ({t.phone})
                      </p>
                    </div>

                    <div className="flex flex-col items-end gap-1">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        t.priority === 'জরুরি'
                          ? 'bg-rose-100 text-rose-800 border border-rose-300'
                          : 'bg-amber-100 text-amber-800 border border-amber-300'
                      }`}>
                        {t.priority}
                      </span>
                      <span className="text-[10px] text-gray-400">
                        {new Date(t.createdAt).toLocaleDateString('bn-BD')}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-gray-700 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    "{t.description}"
                  </p>

                  {t.aiSuggestedReply && (
                    <div className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-200/80 space-y-1">
                      <span className="text-[11px] font-bold text-emerald-900 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                        Gemini AI প্রস্তাবিত সরকারি দাপ্তরিক উত্তর:
                      </span>
                      <p className="text-xs text-emerald-950 font-medium">
                        {t.aiSuggestedReply}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* SUB-TAB 3: CERTIFICATE TRANSLATION TO ENGLISH */}
      {activeSubTab === 'translation' && (
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-5">
          <div className="border-b pb-3 flex items-center justify-between">
            <h3 className="text-sm font-bold text-gray-900 flex items-center gap-2">
              <Languages className="w-4 h-4 text-emerald-700" />
              <span>আন্তর্জাতিক ও পাসপোর্ট ব্যবহারের জন্য সনদপত্র ইংরেজি অনুবাদক</span>
            </h3>
            <span className="text-xs text-emerald-800 font-semibold bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              Bengali → Official Legal English
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">আবেদনকারীর নাম:</label>
              <input
                type="text"
                value={transInputName}
                onChange={(e) => setTransInputName(e.target.value)}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bengali"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">গ্রাম:</label>
              <input
                type="text"
                value={transInputVillage}
                onChange={(e) => setTransInputVillage(e.target.value)}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bengali"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">সনদের ধরন:</label>
              <input
                type="text"
                value={transInputCertType}
                onChange={(e) => setTransInputCertType(e.target.value)}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bengali"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-gray-700 block mb-1">মূল বাংলা দাপ্তরিক প্রত্যয়ন বিবরণী (Body Text):</label>
            <textarea
              rows={3}
              value={transInputBody}
              onChange={(e) => setTransInputBody(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bengali"
            ></textarea>
          </div>

          <button
            onClick={handleTranslate}
            disabled={isTranslating}
            className="w-full py-2.5 px-4 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
          >
            {isTranslating ? (
              <RefreshCw className="w-4 h-4 animate-spin text-emerald-300" />
            ) : (
              <Languages className="w-4 h-4 text-emerald-300" />
            )}
            <span>Gemini AI দিয়ে অফিশিয়াল ইংরেজিতে অনুবাদ করুন</span>
          </button>

          {translatedText && (
            <div className="p-4 rounded-xl bg-slate-900 text-white space-y-2 border border-slate-800">
              <div className="flex items-center justify-between text-xs text-emerald-400 font-bold border-b border-slate-800 pb-2">
                <span>Official English Certificate Paragraph:</span>
                <button
                  onClick={() => navigator.clipboard.writeText(translatedText)}
                  className="hover:underline text-emerald-300"
                >
                  কপি করুন
                </button>
              </div>
              <p className="text-xs text-slate-200 font-mono leading-relaxed pt-1">
                {translatedText}
              </p>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
