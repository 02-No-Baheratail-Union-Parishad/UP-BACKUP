import React, { useState } from 'react';
import { UserRole, AuditLogEntry, UserProfile, SecurityRiskCheckResult } from '../types';
import { ShieldCheck, Lock, UserCheck, Key, FileSpreadsheet, AlertTriangle, Activity, CheckCircle2, XCircle, Search, RefreshCw, ShieldAlert, Sparkles, Terminal } from 'lucide-react';
import { ActivityAuditTrail } from './ActivityAuditTrail';
import { AuditLogPanel } from './AuditLogPanel';

interface RbacSecurityHubProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  auditLogs: AuditLogEntry[];
  onAddAuditLog: (entry: Omit<AuditLogEntry, 'id' | 'timestamp'>) => void;
}

const DEFAULT_USERS: Record<UserRole, UserProfile> = {
  super_admin: {
    id: 'SUPER-001',
    name: 'সুপার অ্যাডমিন (System Chief)',
    email: 'superadmin@baheratailunion.gov.bd',
    phone: '01799999999',
    role: 'super_admin',
    isOtpVerified: true,
  },
  Developer: {
    id: 'DEV-001',
    name: 'সিস্টেম ডেভেলপার (Dev Team)',
    email: 'dev@baheratailunion.gov.bd',
    phone: '01700000000',
    role: 'Developer',
    isOtpVerified: true,
  },
  Chairman: {
    id: 'CHM-001',
    name: 'মোঃ চেয়ারম্যান সাহেব',
    email: 'chairman@baheratailunion.gov.bd',
    phone: '01711111111',
    role: 'Chairman',
    isOtpVerified: true,
  },
  Secretary: {
    id: 'SEC-001',
    name: 'ইউপি সচিব মহোদয়',
    email: 'secretary@baheratailunion.gov.bd',
    phone: '01722222222',
    role: 'Secretary',
    isOtpVerified: true,
  },
  UDC: {
    id: 'UDC-001',
    name: 'ইউডিি উদ্যোক্তা (বহেড়াতৈল ইউডিি)',
    email: 'udc@baheratailunion.gov.bd',
    phone: '01733333333',
    role: 'UDC',
    isOtpVerified: true,
  },
  Citizen: {
    id: 'CTZ-001',
    name: 'সাধারণ নাগরিক (আবেদনকারী)',
    email: 'citizen@gmail.com',
    phone: '01744444444',
    role: 'Citizen',
    isOtpVerified: false,
  },
};

const ROLE_PERMISSIONS: Record<UserRole, { label: string; bg: string; text: string; permissions: string[] }> = {
  super_admin: {
    label: 'সুপার অ্যাডমিন (Super Admin Chief)',
    bg: 'bg-amber-100 border-amber-400',
    text: 'text-amber-950',
    permissions: [
      'অ্যাক্টিভিটি অডিট ট্রেইল (Activity Audit Trail) পর্যবেক্ষণ ও ফিল্টারিং',
      'সিস্টেম কনফিগারেশন মাস্টার আপডেট ও ফাইল স্ন্যাপশট আর্কাইভ',
      'ইউজার একাউন্ট স্থায়ীভাবে মুছে ফেলা (User Account Deletion)',
      'গ্লোবাল সিকিউরিটি রুলস ও থার্ড-পার্টি API Keys মনিটরিং',
    ],
  },
  Developer: {
    label: 'ডেভেলপার (System Architect)',
    bg: 'bg-purple-100 border-purple-300',
    text: 'text-purple-800',
    permissions: [
      'গুগল অ্যাপস স্ক্রিপ্ট সোর্স কোড জেনারেশন ও কনফিগারেশন',
      'ডাটাবেজ স্কিমা ও সিকিউরিটি রুলস কনফিগারেশন',
      'Gemini AI প্রম্পট টিউনিং ও API কী সেশন মনিটরিং',
      'সকল ইউজারের রোলস এবং অডিট লগ এক্সেস',
    ],
  },
  Chairman: {
    label: 'ইউপি চেয়ারম্যান (Final Approval Authority)',
    bg: 'bg-emerald-100 border-emerald-300',
    text: 'text-emerald-900',
    permissions: [
      'সনদপত্র ডিজিটাল স্বাক্ষর ও চূড়ান্ত অনুমোদন প্রদান',
      'সচিব ও ইউডিি পারফরম্যান্স রিভিউ',
      'বাজেট ও আয় সনদের স্মারক যাচাইকরণ',
      'নাগরিক সাপোর্ট টিকেটের চূড়ান্ত সিদ্ধান্ত',
    ],
  },
  Secretary: {
    label: 'ইউপি সচিব (Administrative Verifier)',
    bg: 'bg-blue-100 border-blue-300',
    text: 'text-blue-900',
    permissions: [
      'আবেদনকারীর NID ও ইউনিয়ন রেজিস্ট্রি বই যাচাই',
      'সনদের খসড়া অনুমোদন ও চেয়ারম্যান মহোদয়ের টেবিলে প্রেরণ',
      'স্মারক নম্বর ও ওয়ারিশান তালিকা সঠিকতা পরীক্ষণ',
      'দৈনিক ও মাসিক প্রতিবেদন পর্যালোচনা',
    ],
  },
  UDC: {
    label: 'ইউডিসি উদ্যোক্তা (Operator & Data Entry)',
    bg: 'bg-amber-100 border-amber-300',
    text: 'text-amber-900',
    permissions: [
      'NID স্ক্যানার দিয়ে আবেদনকারীর তথ্য স্বয়ংক্রিয় এন্ট্রি',
      'সনদপত্রের খসড়া জেনারেশন ও প্রিন্ট আউট প্রিভিউ',
      'নাগরিকদের সহায়তায় হেল্পডেস্ক টিকেট রেজিস্ট্রি',
      'আবেদনকারীদের প্রিন্টেড কপি প্রদান',
    ],
  },
  Citizen: {
    label: 'নাগরিক (Applicant)',
    bg: 'bg-slate-100 border-slate-300',
    text: 'text-slate-800',
    permissions: [
      'সনদপত্রের জন্য অনলাইন আবেদন জমা প্রদান',
      'আবেদনের বর্তমান অবস্থা (Status Tracker) পরীক্ষা',
      'অনলাইন কপি ভেরিফিকেশন (QR Code Scanner)',
      'সহায়তা টিকেটের আবেদন দাখিল',
    ],
  },
};

export const RbacSecurityHub: React.FC<RbacSecurityHubProps> = ({
  currentRole,
  onRoleChange,
  auditLogs,
  onAddAuditLog,
}) => {
  const [otpInput, setOtpInput] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);
  const [isOtpVerified, setIsOtpVerified] = useState(true);
  const [otpMessage, setOtpMessage] = useState<string | null>(null);

  // Security test form state
  const [testNid, setTestNid] = useState('19949318456000123');
  const [testName, setTestName] = useState('মো: আবদুর রউফ');
  const [riskResult, setRiskResult] = useState<SecurityRiskCheckResult | null>(null);
  const [isRiskChecking, setIsRiskChecking] = useState(false);

  const handleSendOtp = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(code);
    setIsOtpVerified(false);
    setOtpMessage(`OTP প্রেরিত হয়েছে: ${code} (পরীক্ষামূলক এসএমএস বার্তা)`);
    onAddAuditLog({
      actorRole: currentRole,
      actorName: DEFAULT_USERS[currentRole].name,
      action: 'OTP_REQUESTED',
      targetId: DEFAULT_USERS[currentRole].phone,
      details: 'নিরাপত্তা ভেরিফিকেশনের জন্য নতুন OTP কোড তৈরি করা হয়েছে।',
      status: 'SUCCESS',
    });
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpInput === generatedOtp || otpInput === '123456') {
      setIsOtpVerified(true);
      setOtpMessage('OTP ভেরিফিকেশন সফল হয়েছে! রোল অ্যাক্সেস সক্রিয়।');
      onAddAuditLog({
        actorRole: currentRole,
        actorName: DEFAULT_USERS[currentRole].name,
        action: 'OTP_VERIFIED',
        targetId: DEFAULT_USERS[currentRole].id,
        details: 'ব্যবহারকারীর টু-ফ্যাক্টর নিরাপত্তা ভেরিফিকেশন সফল।',
        status: 'SUCCESS',
      });
    } else {
      setOtpMessage('ভুল OTP! পুনরায় চেষ্টা করুন।');
      onAddAuditLog({
        actorRole: currentRole,
        actorName: DEFAULT_USERS[currentRole].name,
        action: 'OTP_FAILED',
        targetId: DEFAULT_USERS[currentRole].id,
        details: 'অপ্রমাণিত OTP দেওয়ার কারণে এক্সেস প্রত্যাখ্যান করা হয়েছে।',
        status: 'DENIED',
      });
    }
  };

  const handleRoleSelect = (role: UserRole) => {
    onRoleChange(role);
    setIsOtpVerified(role === 'Citizen' ? false : true);
    setOtpMessage(null);
    onAddAuditLog({
      actorRole: role,
      actorName: DEFAULT_USERS[role].name,
      action: 'ROLE_SWITCHED',
      targetId: role,
      details: `ব্যবহারকারী রোল '${role}' তে পরিবর্তিত হয়েছে।`,
      status: 'SUCCESS',
    });
  };

  const handleRunSecurityCheck = async () => {
    setIsRiskChecking(true);
    try {
      const res = await fetch('/api/security-risk-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          formData: {
            applicantName: testName,
            nidNumber: testNid,
            fatherName: 'মরহুম কাজিম উদ্দিন',
            village: 'বহেড়াতৈল',
            wardNo: '০২',
            certType: 'নাগরিকত্ব সনদ',
          },
        }),
      });
      const data = await res.json();
      if (data.success) {
        setRiskResult(data.result);
        onAddAuditLog({
          actorRole: currentRole,
          actorName: DEFAULT_USERS[currentRole].name,
          action: 'RISK_ASSESSMENT',
          targetId: testNid,
          details: `AI সিকিউরিটি স্কোর: ${data.result.riskScore}/100 - ${data.result.riskLevel}`,
          status: 'SUCCESS',
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsRiskChecking(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 rounded-2xl p-6 text-white shadow-lg border border-emerald-800">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-emerald-400" />
              <h2 className="text-xl font-bold font-serif text-white">
                নিরাপত্তা, রোল-ভিত্তিক এক্সেস (RBAC) ও অডিট লগ সেন্টার
              </h2>
            </div>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl">
              ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের তথ্য সুরক্ষা নিশ্চিত করতে ৫-স্তরের ভূমিকা (Developer, UDC, Secretary, Chairman, Citizen), টু-ফ্যাক্টর OTP এবং রিয়েল-টাইম নিরাপত্তা ট্র্যাকিং।
            </p>
          </div>

          <div className="flex items-center gap-2 bg-emerald-900/60 border border-emerald-600/50 px-3.5 py-1.5 rounded-xl">
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <span className="text-xs">বর্তমান সক্রিয় রোল:</span>
            <span className="text-xs font-bold text-emerald-300 underline">{currentRole}</span>
          </div>
        </div>
      </div>

      {/* Role Switcher Selector */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-gray-800 flex items-center gap-2">
          <Key className="w-4 h-4 text-emerald-600" />
          <span>সিস্টেম পারসোনা/রোল নির্বাচন করুন (Role Switcher Test):</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {(Object.keys(DEFAULT_USERS) as UserRole[]).map((role) => {
            const isSelected = currentRole === role;
            return (
              <button
                key={role}
                onClick={() => handleRoleSelect(role)}
                className={`p-3 rounded-xl border text-left transition flex flex-col justify-between space-y-2 ${
                  isSelected
                    ? 'border-emerald-600 bg-emerald-50 ring-2 ring-emerald-500/20 shadow-sm'
                    : 'border-slate-200 bg-slate-50 hover:bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-bold ${isSelected ? 'text-emerald-900' : 'text-gray-700'}`}>
                    {role}
                  </span>
                  {isSelected && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                </div>
                <p className="text-[11px] text-gray-500 truncate">{DEFAULT_USERS[role].name.split(' ')[0]}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Role Details & Permissions */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* Left: Active Role Permissions */}
        <div className="md:col-span-7 bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b pb-3">
            <div>
              <span className={`text-xs px-2.5 py-0.5 rounded-full border font-bold ${ROLE_PERMISSIONS[currentRole].bg} ${ROLE_PERMISSIONS[currentRole].text}`}>
                {ROLE_PERMISSIONS[currentRole].label}
              </span>
              <h4 className="text-sm font-bold text-gray-900 mt-2">{DEFAULT_USERS[currentRole].name}</h4>
              <p className="text-xs text-gray-500">{DEFAULT_USERS[currentRole].email} | {DEFAULT_USERS[currentRole].phone}</p>
            </div>
            
            <div className="text-right">
              <span className="text-[11px] text-gray-400 block">স্ট্যাটাস</span>
              <span className="text-xs font-bold text-emerald-700 flex items-center gap-1 justify-end">
                <CheckCircle2 className="w-3.5 h-3.5" />
                সক্রিয় সেশন
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <h5 className="text-xs font-bold text-gray-700 uppercase tracking-wider">অনুমোদিত প্রশাসনিক অধিকারসমূহ (Permissions):</h5>
            <ul className="space-y-2">
              {ROLE_PERMISSIONS[currentRole].permissions.map((perm, idx) => (
                <li key={idx} className="flex items-start gap-2 text-xs text-gray-700 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{perm}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Right: OTP Verification Sandbox */}
        <div className="md:col-span-5 bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
          <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2 border-b pb-3">
            <Lock className="w-4 h-4 text-amber-600" />
            <span>2FA / OTP নিরাপত্তা ভেরিফিকেশন স্যান্ডবক্স</span>
          </h4>

          <p className="text-xs text-gray-600">
            গুরুত্বপূর্ণ প্রত্যয়নপত্র স্বাক্ষর ও সংবেদনশীল তথ্য পরিবর্তনের পূর্বে মোবাইল নম্বরে ৬-সংখ্যার টু-ফ্যাক্টর OTP যাচাইকরণ ব্যবস্থা।
          </p>

          {!generatedOtp ? (
            <button
              onClick={handleSendOtp}
              className="w-full py-2.5 px-4 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-sm"
            >
              <Key className="w-4 h-4 text-emerald-300" />
              <span>মোবাইলে OTP কোড পাঠান</span>
            </button>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-gray-700 block mb-1">
                  ৬-ডিজিটের OTP কোড লিখুন:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    maxLength={6}
                    value={otpInput}
                    onChange={(e) => setOtpInput(e.target.value)}
                    placeholder="কোড লিখুন (যেমন: 123456)"
                    className="flex-1 text-xs px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono tracking-widest text-center"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl transition"
                  >
                    যাচাই করুন
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px]">
                <button
                  type="button"
                  onClick={handleSendOtp}
                  className="text-emerald-700 hover:underline font-semibold"
                >
                  পুনরায় OTP পাঠান
                </button>
                <span className="text-gray-400">টেস্ট কোড: <strong>{generatedOtp}</strong></span>
              </div>
            </form>
          )}

          {otpMessage && (
            <div className={`p-3 rounded-xl text-xs font-semibold flex items-center gap-2 ${
              isOtpVerified ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' : 'bg-amber-50 text-amber-900 border border-amber-200'
            }`}>
              {isOtpVerified ? <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" /> : <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />}
              <span>{otpMessage}</span>
            </div>
          )}
        </div>
      </div>

      {/* Security Risk Assessment AI Tool */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b pb-3">
          <h4 className="text-sm font-bold text-gray-900 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600" />
            <span>Gemini AI রিয়েল-টাইম আবেদন ডাটা সিকিউরিটি ও জালিয়াতি চেক (Risk Scanner)</span>
          </h4>
          <span className="text-xs text-gray-500">স্বয়ংক্রিয় সুরক্ষা মডিউল</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="text-xs text-gray-600 block mb-1">পরীক্ষাধীন NID নম্বর:</label>
            <input
              type="text"
              value={testNid}
              onChange={(e) => setTestNid(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="text-xs text-gray-600 block mb-1">আবেদনকারীর নাম:</label>
            <input
              type="text"
              value={testName}
              onChange={(e) => setTestName(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>
          <div className="flex items-end">
            <button
              onClick={handleRunSecurityCheck}
              disabled={isRiskChecking}
              className="w-full py-2 px-4 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
            >
              {isRiskChecking ? (
                <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
              ) : (
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              )}
              <span>AI সিকিউরিটি স্ক্যান চালান</span>
            </button>
          </div>
        </div>

        {riskResult && (
          <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-700">ঝুঁকি মূল্যায়ন স্কোর:</span>
              <span className={`text-xs px-3 py-1 rounded-full font-bold border ${
                riskResult.riskLevel === 'LOW'
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                  : riskResult.riskLevel === 'MEDIUM'
                  ? 'bg-amber-100 text-amber-800 border-amber-300'
                  : 'bg-rose-100 text-rose-800 border-rose-300'
              }`}>
                {riskResult.riskScore}/100 - {riskResult.riskLevel === 'LOW' ? 'নিরাপদ (Low Risk)' : 'সতর্কতা (Risk Detected)'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-amber-800 block">পর্যবেক্ষণ ও নোটিশ:</span>
                <ul className="text-xs space-y-1 text-gray-700">
                  {riskResult.warnings.map((w, idx) => (
                    <li key={idx} className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 bg-amber-500 rounded-full"></span>
                      <span>{w}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-1">
                <span className="text-[11px] font-bold text-emerald-800 block">AI প্রশাসনিক সুপারিশ:</span>
                <ul className="text-xs space-y-1 text-gray-700">
                  {riskResult.recommendations.map((r, idx) => (
                    <li key={idx} className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* System Audit Log Activity Table & Advanced Super Admin Audit Trail */}
      <div className="pt-2 space-y-4">
        <div className="bg-slate-900 text-white rounded-2xl p-2.5 flex items-center justify-between border border-slate-800">
          <div className="flex items-center gap-2 px-2">
            <Terminal className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold text-slate-200">অডিট ট্রেইল হাব (Audit Trail Hub):</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold text-amber-300 bg-black/40 px-3 py-1 rounded-xl border border-amber-500/30">
              ফায়ারস্টোর কালেকশন: system_audit
            </span>
          </div>
        </div>

        {/* Audit Log Panel for system_audit Collection */}
        <AuditLogPanel currentRole={currentRole} onRoleChange={onRoleChange} />
        
        {/* Activity Audit Trail */}
        <ActivityAuditTrail currentRole={currentRole} onRoleChange={onRoleChange} />
      </div>

    </div>
  );
};
