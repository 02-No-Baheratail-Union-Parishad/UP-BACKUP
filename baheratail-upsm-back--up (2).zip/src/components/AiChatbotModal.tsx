import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, X, Sparkles, MessageSquare, Loader2, User, RefreshCw, HelpCircle } from 'lucide-react';

interface ChatMessage {
  sender: 'user' | 'bot';
  text: string;
  time: string;
}

const QUICK_SUGGESTIONS = [
  'ওয়ারিশ সনদের নিয়ম কী?',
  'নাগরিকত্ব সনদে কী কী লাগে?',
  'ইউপি অফিসের সময়সূচী কত?',
  'অনলাইন ভেরিফিকেশন কীভাবে করবো?'
];

export const AiChatbotModal: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: 'bot',
      text: 'আসসালামু আলাইকুম! আমি ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল সহায়তা চ্যাটবট। কীভাবে আপনাকে সাহায্য করতে পারি?',
      time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSend = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim() || loading) return;

    const userTime = new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });
    const newMsg: ChatMessage = { sender: 'user', text: query.trim(), time: userTime };

    setMessages((prev) => [...prev, newMsg]);
    if (!textToSend) setInput('');
    setLoading(true);

    try {
      const historyPayload = messages
        .filter((m) => m.sender === 'user' || m.sender === 'bot')
        .slice(-6)
        .map((m) => ({
          role: m.sender === 'user' ? 'user' : 'model',
          parts: [{ text: m.text }]
        }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: query.trim(), history: historyPayload })
      });

      const data = await res.json();
      const botTime = new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });

      if (res.ok && data.reply) {
        setMessages((prev) => [...prev, { sender: 'bot', text: data.reply, time: botTime }]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'bot',
            text: data.error || 'দুঃখিত, এআই রেসপন্স সংযোগ বিচ্ছিন্ন হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।',
            time: botTime
          }
        ]);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'bot',
          text: 'নেটওয়ার্ক সংযোগ ত্রুটি। ইন্টারনেট বা এআই সার্ভার চেক করুন।',
          time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="no-print">
      {/* Floating Action Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-5 right-5 z-50 bg-gradient-to-r from-emerald-800 to-teal-900 text-amber-300 p-3.5 sm:p-4 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition flex items-center gap-2.5 border-2 border-amber-400 cursor-pointer"
          title="০২নং বহেড়াতৈল ইউপি এআই সহকারী"
        >
          <div className="relative">
            <Bot className="w-6 h-6 text-amber-300" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-emerald-950 animate-ping" />
          </div>
          <span className="hidden sm:inline font-bold text-xs pr-1">এআই নাগরিক সহকারী</span>
        </button>
      )}

      {/* Chat Window Modal */}
      {isOpen && (
        <div className="fixed bottom-4 right-4 z-50 w-[92vw] sm:w-[420px] max-h-[85vh] h-[550px] bg-white rounded-3xl shadow-2xl border-2 border-emerald-800 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="bg-gradient-to-r from-emerald-900 via-emerald-950 to-teal-950 text-white p-4 flex items-center justify-between border-b border-emerald-800 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-emerald-800 border border-amber-400 flex items-center justify-center text-amber-300 shrink-0 shadow">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-xs sm:text-sm text-white flex items-center gap-1.5">
                  <span>০২নং বহেড়াতৈল ইউপি এআই সহকারী</span>
                  <Sparkles className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
                </h3>
                <p className="text-[10px] text-emerald-200 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>গুগল Gemini 3.6 দ্বারা পরিচালিত</span>
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="w-8 h-8 rounded-full bg-emerald-800/80 hover:bg-emerald-700 text-emerald-200 flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Suggestions Pills */}
          <div className="bg-emerald-50/60 p-2 border-b border-emerald-100 overflow-x-auto flex items-center gap-1.5 shrink-0 no-scrollbar">
            <span className="text-[10px] font-bold text-emerald-900 shrink-0 pl-1 flex items-center gap-1">
              <HelpCircle className="w-3 h-3 text-emerald-700" />
              <span>প্রশ্ন দেখুন:</span>
            </span>
            {QUICK_SUGGESTIONS.map((s, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(s)}
                className="text-[10px] font-semibold bg-white hover:bg-emerald-100 text-emerald-900 px-2.5 py-1 rounded-full border border-emerald-200 shrink-0 transition cursor-pointer"
              >
                {s}
              </button>
            ))}
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/50 text-xs">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`flex gap-2 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {m.sender === 'bot' && (
                  <div className="w-7 h-7 rounded-full bg-emerald-900 text-amber-300 flex items-center justify-center shrink-0 mt-0.5 border border-emerald-700 shadow-sm">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[80%] rounded-2xl p-3 shadow-sm ${
                    m.sender === 'user'
                      ? 'bg-emerald-800 text-white rounded-tr-none font-medium'
                      : 'bg-white text-slate-900 border border-slate-200 rounded-tl-none font-sans'
                  }`}
                >
                  <p className="whitespace-pre-wrap leading-relaxed">{m.text}</p>
                  <span
                    className={`block text-[9px] mt-1 text-right ${
                      m.sender === 'user' ? 'text-emerald-200' : 'text-slate-400'
                    }`}
                  >
                    {m.time}
                  </span>
                </div>

                {m.sender === 'user' && (
                  <div className="w-7 h-7 rounded-full bg-slate-700 text-white flex items-center justify-center shrink-0 mt-0.5 border border-slate-600 shadow-sm">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="flex gap-2 justify-start items-center text-slate-500">
                <div className="w-7 h-7 rounded-full bg-emerald-900 text-amber-300 flex items-center justify-center shrink-0 border border-emerald-700">
                  <Bot className="w-4 h-4 animate-bounce" />
                </div>
                <div className="bg-white border border-slate-200 px-3 py-2 rounded-2xl rounded-tl-none flex items-center gap-2 shadow-sm">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-700" />
                  <span className="text-[11px] font-semibold text-emerald-900">এআই উত্তর ভাবছে...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Footer */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="আপনার প্রশ্ন বাংলায় লিখুন..."
              className="flex-1 px-3 py-2 bg-slate-100 border border-slate-300 rounded-xl text-xs font-medium text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
            />
            <button
              type="submit"
              disabled={!input.trim() || loading}
              className="p-2.5 bg-emerald-800 hover:bg-emerald-700 text-amber-300 rounded-xl transition disabled:opacity-50 cursor-pointer shadow-sm"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
