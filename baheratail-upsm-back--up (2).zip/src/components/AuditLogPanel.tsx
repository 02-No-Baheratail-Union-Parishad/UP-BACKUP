import React, { useState, useEffect, useMemo } from 'react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  Lock, 
  Activity, 
  Search, 
  Filter, 
  Calendar, 
  RefreshCw, 
  Download, 
  FileJson, 
  PlusCircle, 
  Database, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Clock, 
  User, 
  Eye, 
  X, 
  Flame, 
  SlidersHorizontal,
  ChevronRight,
  Sparkles,
  FileText,
  Key
} from 'lucide-react';
import { UserRole, AuditLogEntry } from '../types';
import { 
  subscribeSystemAuditLogsFromFirebase, 
  fetchSystemAuditLogsFromFirebase, 
  saveSystemAuditLogToFirebase 
} from '../firebase';

interface AuditLogPanelProps {
  currentRole: UserRole | string;
  onRoleChange?: (role: UserRole) => void;
}

export const AuditLogPanel: React.FC<AuditLogPanelProps> = ({ currentRole, onRoleChange }) => {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>('');

  // Filters state
  const [selectedActionType, setSelectedActionType] = useState<string>('ALL');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  // UI modal state
  const [selectedLog, setSelectedLog] = useState<AuditLogEntry | null>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [notificationMsg, setNotificationMsg] = useState<string | null>(null);

  // 1. Check Restricted Access: Super Admin Only
  const isSuperAdmin = currentRole === 'super_admin';

  // 2. Real-time Firestore subscription to 'system_audit' collection
  useEffect(() => {
    if (!isSuperAdmin) return;

    setIsLoading(true);
    const unsubscribe = subscribeSystemAuditLogsFromFirebase((retrievedLogs) => {
      setLogs(retrievedLogs);
      setIsLoading(false);
      setLastSyncTime(new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    });

    return () => unsubscribe();
  }, [isSuperAdmin]);

  // Manual Refresh Handler
  const handleRefresh = async () => {
    if (!isSuperAdmin) return;
    setIsRefreshing(true);
    try {
      const freshLogs = await fetchSystemAuditLogsFromFirebase();
      setLogs(freshLogs);
      setLastSyncTime(new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } catch (error) {
      console.error('Error refreshing system_audit logs:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  // Sample Audit Actions list for quick creation & filter
  const ACTION_TYPES = [
    { value: 'ALL', label: 'সকল অ্যাকশন (All Actions)' },
    { value: 'CERTIFICATE_CREATE', label: 'সনদপত্র তৈরি (Certificate Create)' },
    { value: 'CERTIFICATE_UPDATE', label: 'সনদ সংশোধন (Certificate Edit)' },
    { value: 'CERTIFICATE_DELETE', label: 'সনদ বিলোপ (Certificate Delete)' },
    { value: 'CONFIG_MASTER_UPDATE', label: 'কনফিগারেশন আপডেট (Master Config)' },
    { value: 'USER_ROLE_CHANGE', label: 'ব্যবহারকারী রোল পরিবর্তন (Role Switch)' },
    { value: 'LOGIN_SUCCESS', label: 'সফল লগইন (User Login)' },
    { value: 'OTP_VERIFICATION', label: 'ওটিপি ভেরিফিকেশন (OTP Verified)' },
    { value: 'SECURITY_ALERT', label: 'নিরাপত্তা অ্যালার্ট (Security Threat)' },
    { value: 'SYSTEM_ERROR', label: 'সিস্টেম এরর (System Exception)' },
  ];

  // Quick Date Range Presets
  const setPresetDateRange = (preset: 'today' | '7days' | '30days' | 'all') => {
    const now = new Date();
    if (preset === 'today') {
      const todayStr = now.toISOString().split('T')[0];
      setStartDate(todayStr);
      setEndDate(todayStr);
    } else if (preset === '7days') {
      const past = new Date();
      past.setDate(now.getDate() - 7);
      setStartDate(past.toISOString().split('T')[0]);
      setEndDate(now.toISOString().split('T')[0]);
    } else if (preset === '30days') {
      const past = new Date();
      past.setDate(now.getDate() - 30);
      setStartDate(past.toISOString().split('T')[0]);
      setEndDate(now.toISOString().split('T')[0]);
    } else {
      setStartDate('');
      setEndDate('');
    }
  };

  // Filtered logs computation
  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      // 1. Action Type Filter
      if (selectedActionType !== 'ALL') {
        const actionMatch = log.action.toUpperCase().includes(selectedActionType.toUpperCase());
        const categoryMatch = (log.category || '').toUpperCase().includes(selectedActionType.toUpperCase());
        if (!actionMatch && !categoryMatch) return false;
      }

      // 2. Status Filter
      if (selectedStatus !== 'ALL') {
        if (log.status !== selectedStatus) return false;
      }

      // 3. Search Term Filter
      if (searchTerm.trim() !== '') {
        const term = searchTerm.toLowerCase();
        const inAction = (log.action || '').toLowerCase().includes(term);
        const inActorName = (log.actorName || '').toLowerCase().includes(term);
        const inActorEmail = (log.actorEmail || '').toLowerCase().includes(term);
        const inTargetId = (log.targetId || '').toLowerCase().includes(term);
        const inDetails = (log.details || '').toLowerCase().includes(term);
        if (!inAction && !inActorName && !inActorEmail && !inTargetId && !inDetails) return false;
      }

      // 4. Date Range Filter
      if (startDate) {
        const logDate = new Date(log.timestamp);
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        if (logDate < start) return false;
      }

      if (endDate) {
        const logDate = new Date(log.timestamp);
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        if (logDate > end) return false;
      }

      return true;
    });
  }, [logs, selectedActionType, selectedStatus, searchTerm, startDate, endDate]);

  // Handle adding sample log to Firestore 'system_audit' collection
  const handleSeedSampleAuditLog = async () => {
    if (!isSuperAdmin) return;
    setIsSimulating(true);
    try {
      const sampleActions = [
        { action: 'CERTIFICATE_CREATE', category: 'CERTIFICATE', details: 'নতুন নাগরিকত্ব সনদ তৈরি করা হয়েছে (memoNo: BHT-2026-90412)', targetId: 'BHT-2026-90412', status: 'SUCCESS' as const },
        { action: 'CONFIG_MASTER_UPDATE', category: 'CONFIG', details: 'ইউনিয়ন পরিষদের লোগো ও চেয়ারম্যান ডিজিটাল স্বাক্ষর আপডেট করা হয়েছে', targetId: 'master_config', status: 'SUCCESS' as const },
        { action: 'SECURITY_ALERT', category: 'SECURITY', details: 'অননুমোদিত IP থেকে একাধিকবার ব্যর্থ লগইন প্রচেষ্টা শনাক্তকরণ (192.168.1.45)', targetId: 'ip_192_168_1_45', status: 'WARNING' as const },
        { action: 'USER_ROLE_CHANGE', category: 'USER_MANAGEMENT', details: 'ইউজার `secretary@baheratail.gov.bd` কে Secretary রোল প্রদান করা হয়েছে', targetId: 'USR-SEC-882', status: 'SUCCESS' as const },
        { action: 'SYSTEM_ERROR', category: 'SYSTEM', details: 'ক্লাউড প্রিন্টার এপিআই সংযোগ বিচ্ছিন্নতা শনাক্ত করা হয়েছে', targetId: 'cloud_print_api', status: 'DENIED' as const },
      ];

      const pick = sampleActions[Math.floor(Math.random() * sampleActions.length)];

      await saveSystemAuditLogToFirebase({
        timestamp: new Date().toISOString(),
        actorRole: 'super_admin',
        actorName: 'সুপার অ্যাডমিন (System Chief)',
        actorEmail: 'superadmin@baheratailunion.gov.bd',
        action: pick.action,
        category: pick.category as any,
        targetId: pick.targetId,
        details: pick.details,
        status: pick.status,
        ipAddress: '103.145.22.10',
        changesPayload: JSON.stringify({ event: 'MANUAL_AUDIT_TRIGGER', triggeredAt: new Date().toISOString() }, null, 2)
      });

      setNotificationMsg('সফলভাবে "system_audit" ফায়ারস্টোর কালেকশনে একটি লাইভ টেস্ট অডিট রেকর্ড যোগ করা হয়েছে!');
      setTimeout(() => setNotificationMsg(null), 4000);
    } catch (err: any) {
      console.error('Error seeding audit log:', err);
      setNotificationMsg('ত্রুটি: ' + (err.message || 'রেকর্ড যোগ করা যায়নি'));
    } finally {
      setIsSimulating(false);
    }
  };

  // Export JSON file handler
  const handleExportJSON = () => {
    const jsonStr = JSON.stringify(filteredLogs, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `system_audit_logs_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  // Export CSV handler
  const handleExportCSV = () => {
    const headers = ['ID', 'Timestamp', 'Actor Role', 'Actor Name', 'Action', 'Target ID', 'Status', 'Details'];
    const rows = filteredLogs.map((l) => [
      l.id,
      l.timestamp,
      l.actorRole,
      `"${(l.actorName || '').replace(/"/g, '""')}"`,
      l.action,
      l.targetId,
      l.status,
      `"${(l.details || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `system_audit_logs_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  // =========================================================
  // RESTRICTED ACCESS SCREEN: If currentRole !== 'super_admin'
  // =========================================================
  if (!isSuperAdmin) {
    return (
      <div className="bg-gradient-to-br from-slate-900 via-rose-950 to-slate-950 text-white rounded-3xl p-8 border-2 border-rose-600/80 shadow-2xl space-y-6 max-w-4xl mx-auto my-6">
        <div className="flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left border-b border-rose-800/60 pb-6">
          <div className="w-16 h-16 rounded-2xl bg-rose-500/20 border-2 border-rose-500/50 flex items-center justify-center shrink-0 shadow-inner animate-pulse">
            <Lock className="w-9 h-9 text-rose-400" />
          </div>
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-bold rounded-full">
              <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
              <span>অনুমতি সংরক্ষিত (Restricted Access)</span>
            </div>
            <h2 className="text-2xl font-black text-white tracking-tight">
              সিস্টেম অডিট প্যানেল (System Audit Panel)
            </h2>
            <p className="text-xs text-rose-200">
              ফায়ারস্টোর <code className="bg-black/50 px-1.5 py-0.5 rounded font-mono text-amber-300">system_audit</code> কালেকশন ও সিকিউরিটি ফিল্টার ব্যবহারের অনুমতি সুরক্ষিত।
            </p>
          </div>
        </div>

        <div className="bg-black/40 rounded-2xl p-5 border border-rose-900/60 space-y-4">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1.5 leading-relaxed text-rose-100">
              <p className="font-bold text-amber-300">
                নিরাপত্তা সতর্কতা:
              </p>
              <p>
                আপনার বর্তমান অর্পিত রোল: <span className="bg-rose-900/80 px-2 py-0.5 rounded font-bold text-white border border-rose-600">{currentRole}</span>।
                নিরাপত্তা নীতিমালা অনুযায়ী <code className="bg-black px-1 text-emerald-400 font-mono">system_audit</code> ডেটাবেস লগস, সিকিউরিটি অডিট এবং অ্যাক্টিভিটি পরিবর্তন দেখতে শুধুমাত্র <span className="text-amber-300 font-bold underline">super_admin</span> রোলের অধিকার রয়েছে।
              </p>
            </div>
          </div>

          {onRoleChange && (
            <div className="pt-3 border-t border-rose-900/50 flex flex-col sm:flex-row items-center justify-between gap-3">
              <span className="text-xs text-slate-300 font-medium">
                পরীক্ষার জন্য 'সুপার অ্যাডমিন' রোলে স্যুইচ করতে চান?
              </span>
              <button
                onClick={() => onRoleChange('super_admin')}
                className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs rounded-xl shadow-lg hover:shadow-xl transition flex items-center gap-2 cursor-pointer"
              >
                <Key className="w-4 h-4 text-slate-950" />
                <span>সুপার অ্যাডমিন (super_admin) হিসেবে লগইন করুন</span>
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // =========================================================
  // MAIN SUPER ADMIN PANEL: When currentRole === 'super_admin'
  // =========================================================
  return (
    <div className="space-y-6">
      {/* Top Banner & Title Card */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-950 to-emerald-950 text-white rounded-3xl p-6 shadow-2xl border border-emerald-800/80 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-emerald-800/60 pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 bg-amber-400 text-slate-950 font-black text-[10px] rounded-full uppercase tracking-wider">
                SUPER ADMIN ONLY
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-0.5 bg-emerald-900/80 border border-emerald-500/40 text-emerald-300 text-xs font-bold rounded-full">
                <Flame className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
                <span>ফায়ারস্টোর কালেকশন: system_audit</span>
              </span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-white flex items-center gap-2 tracking-tight">
              <Activity className="w-6 h-6 text-emerald-400" />
              <span>সিস্টেম অডিট লগ প্যানেল (System Audit Panel)</span>
            </h2>
            <p className="text-xs text-emerald-200">
              ফায়ারস্টোর (Firestore) <code className="bg-black/50 px-1.5 py-0.5 rounded font-mono text-amber-300">system_audit</code> কালেকশন হইতে সরাসরি সকল রিয়েল-টাইম অ্যাডমিন ও সিস্টেম কার্যক্রম অডিট লগের ফিল্টারিং
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {lastSyncTime && (
              <span className="px-2.5 py-1 bg-slate-800/90 text-slate-300 text-[10px] font-mono font-semibold rounded-full border border-slate-700">
                সিঙ্ক সময়: {lastSyncTime}
              </span>
            )}

            <button
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="px-3.5 py-2 bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-bold text-xs rounded-xl border border-emerald-600 transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-md"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>রিফ্রেশ</span>
            </button>

            <button
              onClick={handleSeedSampleAuditLog}
              disabled={isSimulating}
              className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-md"
              title="system_audit কালেকশনে একটি নতুন টেস্ট লগ যোগ করুন"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>টেস্ট লগ যোগ করুন</span>
            </button>
          </div>
        </div>

        {/* Notification Alert Message */}
        {notificationMsg && (
          <div className="bg-emerald-900/90 border border-emerald-400 text-emerald-100 px-4 py-2.5 rounded-xl text-xs font-bold flex items-center justify-between animate-fadeIn">
            <span className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-300" />
              <span>{notificationMsg}</span>
            </span>
            <button onClick={() => setNotificationMsg(null)} className="text-emerald-300 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Realtime KPI Counter Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="bg-slate-900/90 p-3.5 rounded-2xl border border-emerald-800/80 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold block">মোট অডিট নথি</span>
            <span className="text-2xl font-black text-white">{logs.length.toLocaleString()} <span className="text-xs text-emerald-400 font-semibold">টি</span></span>
          </div>

          <div className="bg-slate-900/90 p-3.5 rounded-2xl border border-emerald-800/80 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold block">ফিল্টারকৃত রেজাল্ট</span>
            <span className="text-2xl font-black text-amber-300">{filteredLogs.length.toLocaleString()} <span className="text-xs text-amber-400 font-semibold">টি</span></span>
          </div>

          <div className="bg-slate-900/90 p-3.5 rounded-2xl border border-emerald-800/80 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold block">সফল অ্যাকশন</span>
            <span className="text-2xl font-black text-emerald-400">{logs.filter(l => l.status === 'SUCCESS').length} <span className="text-xs text-emerald-500 font-semibold">টি</span></span>
          </div>

          <div className="bg-slate-900/90 p-3.5 rounded-2xl border border-emerald-800/80 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold block">ওয়ার্নিং ও এরর</span>
            <span className="text-2xl font-black text-rose-400">{logs.filter(l => l.status !== 'SUCCESS').length} <span className="text-xs text-rose-500 font-semibold">টি</span></span>
          </div>
        </div>
      </div>

      {/* FILTER CONTROL CARD: Action Type, Date Range & Search */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-md space-y-5">
        <div className="flex items-center justify-between border-b pb-3">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Filter className="w-4 h-4 text-emerald-700" />
            <span>অডিট ফিল্টারিং ও তারিখ ফিল্টার (Filter by Action & Date Range)</span>
          </h3>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportJSON}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 transition flex items-center gap-1.5 cursor-pointer"
            >
              <FileJson className="w-3.5 h-3.5 text-slate-600" />
              <span>JSON এক্সপোর্ট</span>
            </button>
            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 transition flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span>CSV এক্সপোর্ট</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Action Type Filter Dropdown */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
              <SlidersHorizontal className="w-3.5 h-3.5 text-emerald-600" />
              <span>অ্যাকশন টাইপ (Action Type):</span>
            </label>
            <select
              value={selectedActionType}
              onChange={(e) => setSelectedActionType(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
            >
              {ACTION_TYPES.map((act) => (
                <option key={act.value} value={act.value}>
                  {act.label}
                </option>
              ))}
            </select>
          </div>

          {/* Date Range: Start Date */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-emerald-600" />
              <span>শুরুর তারিখ (Start Date):</span>
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
            />
          </div>

          {/* Date Range: End Date */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-emerald-600" />
              <span>শেষের তারিখ (End Date):</span>
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
            />
          </div>

          {/* Status Filter */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>স্ট্যাটাস (Status):</span>
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
            >
              <option value="ALL">সকল স্ট্যাটাস (All Status)</option>
              <option value="SUCCESS">SUCCESS (সফল)</option>
              <option value="WARNING">WARNING (সতর্কতা)</option>
              <option value="DENIED">DENIED / ERROR (প্রত্যাখ্যাত/এরর)</option>
            </select>
          </div>
        </div>

        {/* Free Text Search & Quick Date Presets Row */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="অ্যাকশন, ইউজার, টার্গেট ID বা বিবরণ টাইপ করুন..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-2 text-xs font-medium text-slate-800 focus:ring-2 focus:ring-emerald-500 outline-none"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 flex-wrap w-full sm:w-auto justify-end">
            <span className="text-[11px] font-bold text-slate-500 mr-1">তারিখ নির্বাচন:</span>
            <button
              onClick={() => setPresetDateRange('today')}
              className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-900 text-xs font-bold rounded-lg border border-slate-200 transition cursor-pointer"
            >
              আজকে
            </button>
            <button
              onClick={() => setPresetDateRange('7days')}
              className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-900 text-xs font-bold rounded-lg border border-slate-200 transition cursor-pointer"
            >
              ৭ দিন
            </button>
            <button
              onClick={() => setPresetDateRange('30days')}
              className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-900 text-xs font-bold rounded-lg border border-slate-200 transition cursor-pointer"
            >
              ৩০ দিন
            </button>
            {(startDate || endDate || selectedActionType !== 'ALL' || selectedStatus !== 'ALL' || searchTerm) && (
              <button
                onClick={() => {
                  setStartDate('');
                  setEndDate('');
                  setSelectedActionType('ALL');
                  setSelectedStatus('ALL');
                  setSearchTerm('');
                }}
                className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold rounded-lg border border-rose-200 transition cursor-pointer"
              >
                ফিল্টার রিসেট
              </button>
            )}
          </div>
        </div>
      </div>

      {/* SYSTEM AUDIT LOG TABLE RESULT */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-md overflow-hidden space-y-0">
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-400" />
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-emerald-300">
              'system_audit' কালেকশন রেকর্ডসমূহ ({filteredLogs.length} টি)
            </h4>
          </div>
          <span className="text-[11px] text-slate-400">
            রিয়েল-টাইম ফায়ারস্টোর সিঙ্ক সক্রিয়
          </span>
        </div>

        {isLoading ? (
          <div className="p-12 text-center space-y-3">
            <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin mx-auto" />
            <p className="text-xs font-bold text-slate-600">
              ফায়ারস্টোর 'system_audit' কালেকশন লোড হচ্ছে...
            </p>
          </div>
        ) : filteredLogs.length === 0 ? (
          <div className="p-12 text-center space-y-2">
            <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto" />
            <p className="text-sm font-bold text-slate-800">কোনো অডিট রেকর্ড পাওয়া যায়নি!</p>
            <p className="text-xs text-slate-500">
              আপনার ফিল্টার অথবা সার্চ কোয়েরির সাথে মেলে এমন কোনো রেকর্ড নেই। ফিল্টার পরিবর্তন করে দেখুন।
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <th className="py-3 px-4">সময় ও তারিখ</th>
                  <th className="py-3 px-4">ব্যবহারকারী ও রোল</th>
                  <th className="py-3 px-4">অ্যাকশন টাইপ</th>
                  <th className="py-3 px-4">টার্গেট ID</th>
                  <th className="py-3 px-4">বিস্তারিত বিবরণ</th>
                  <th className="py-3 px-4 text-center">স্ট্যাটাস</th>
                  <th className="py-3 px-4 text-center">ইনস্পেক্ট</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {filteredLogs.map((log) => {
                  const logDate = new Date(log.timestamp);
                  const formattedDate = isNaN(logDate.getTime()) 
                    ? log.timestamp 
                    : logDate.toLocaleDateString('bn-BD', { day: '2-digit', month: 'short', year: 'numeric' }) + ' ' + logDate.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });

                  return (
                    <tr key={log.id} className="hover:bg-slate-50 transition">
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-600 whitespace-nowrap">
                        {formattedDate}
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-bold text-slate-900 block">{log.actorName || 'সিস্টেম'}</span>
                        <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 inline-block mt-0.5">
                          {log.actorRole}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                          {log.action}
                        </span>
                      </td>

                      <td className="py-3 px-4 font-mono text-[11px] text-slate-600">
                        {log.targetId}
                      </td>

                      <td className="py-3 px-4 text-slate-700 max-w-xs truncate">
                        {log.details}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-black ${
                          log.status === 'SUCCESS' 
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : log.status === 'WARNING'
                            ? 'bg-amber-100 text-amber-800 border border-amber-300'
                            : 'bg-rose-100 text-rose-800 border border-rose-300'
                        }`}>
                          {log.status}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => setSelectedLog(log)}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white font-bold text-[11px] rounded-lg transition inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Eye className="w-3 h-3 text-amber-300" />
                          <span>দেখুন</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* INSPECT LOG DETAIL MODAL */}
      {selectedLog && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 text-white rounded-3xl p-6 border border-emerald-700/80 max-w-2xl w-full shadow-2xl space-y-5 animate-scaleIn">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-extrabold text-white">
                  'system_audit' অডিট লগের পূর্ণাঙ্গ বিবরণ
                </h3>
              </div>
              <button
                onClick={() => setSelectedLog(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-slate-400 text-[10px] font-bold block">রেকর্ড আইডি (Document ID):</span>
                  <span className="font-mono text-emerald-300 font-bold">{selectedLog.id}</span>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-slate-400 text-[10px] font-bold block">সময়কাল (Timestamp):</span>
                  <span className="font-mono text-white font-bold">{selectedLog.timestamp}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-slate-400 text-[10px] font-bold block">ব্যবহারকারী ও রোল:</span>
                  <span className="text-white font-bold block">{selectedLog.actorName}</span>
                  <span className="text-emerald-400 font-mono text-[10px]">{selectedLog.actorRole} ({selectedLog.actorEmail || 'N/A'})</span>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-slate-400 text-[10px] font-bold block">অ্যাকশন ও টার্গেট ID:</span>
                  <span className="text-amber-300 font-bold font-mono block">{selectedLog.action}</span>
                  <span className="text-slate-300 font-mono text-[10px]">Target: {selectedLog.targetId}</span>
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-400 text-[10px] font-bold block">বিস্তারিত বিবরণ (Details):</span>
                <p className="text-slate-200 leading-relaxed font-medium">{selectedLog.details}</p>
              </div>

              {selectedLog.changesPayload && (
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-slate-400 text-[10px] font-bold block">JSON Payloads & Changes:</span>
                  <pre className="bg-black/60 p-3 rounded-lg text-emerald-400 font-mono text-[10px] overflow-x-auto max-h-40">
                    {selectedLog.changesPayload}
                  </pre>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end pt-2 border-t border-slate-800">
              <button
                onClick={() => setSelectedLog(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
