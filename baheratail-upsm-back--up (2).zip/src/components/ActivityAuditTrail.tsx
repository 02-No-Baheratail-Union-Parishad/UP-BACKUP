import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  Activity, 
  Search, 
  Filter, 
  RefreshCw, 
  Download, 
  FileJson, 
  Trash2, 
  Lock, 
  UserX, 
  Settings, 
  FileCheck, 
  AlertTriangle, 
  UserCheck, 
  Server, 
  Clock, 
  Eye, 
  CheckCircle2, 
  XCircle, 
  Layers, 
  PlusCircle, 
  Sparkles,
  User,
  Key,
  Globe,
  Sliders,
  ChevronDown,
  ChevronUp,
  X
} from 'lucide-react';
import { UserRole, AuditLogEntry } from '../types';
import { fetchAuditLogsFromFirebase, saveAuditLogToFirebase, subscribeAuditLogsFromFirebase } from '../firebase';

interface ActivityAuditTrailProps {
  currentRole: UserRole;
  onRoleChange?: (role: UserRole) => void;
}

export const ActivityAuditTrail: React.FC<ActivityAuditTrailProps> = ({ currentRole, onRoleChange }) => {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<string>('ALL');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'table' | 'timeline'>('table');
  const [selectedLogModal, setSelectedLogModal] = useState<AuditLogEntry | null>(null);
  const [simulationMsg, setSimulationMsg] = useState<string | null>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [isClearing, setIsClearing] = useState<boolean>(false);

  // Fetch initial audit logs from server API + Firestore subscription
  const loadAuditLogs = async () => {
    setIsLoading(true);
    try {
      // 1. Fetch from server API
      const res = await fetch('/api/admin/audit-logs');
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.logs)) {
          setLogs(data.logs);
        }
      }

      // 2. Fallback or merge with Firestore
      const fsLogs = await fetchAuditLogsFromFirebase();
      if (fsLogs && fsLogs.length > 0) {
        setLogs(prev => {
          const map = new Map();
          [...prev, ...fsLogs].forEach(item => map.set(item.id, item));
          return Array.from(map.values()).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        });
      }
    } catch (err) {
      console.warn('Error loading audit logs:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAuditLogs();

    // Subscribe to Firestore real-time updates for audit logs
    const unsubscribe = subscribeAuditLogsFromFirebase((realtimeLogs) => {
      if (realtimeLogs && realtimeLogs.length > 0) {
        setLogs(prev => {
          const map = new Map();
          [...realtimeLogs, ...prev].forEach(item => map.set(item.id, item));
          return Array.from(map.values()).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        });
      }
    });

    return () => unsubscribe();
  }, []);

  // Handler to trigger simulated administrative audit actions
  const handleSimulateAction = async (
    action: string,
    category: 'CONFIG' | 'USER_MANAGEMENT' | 'CERTIFICATE' | 'SYSTEM' | 'SECURITY',
    targetId: string,
    details: string,
    status: 'SUCCESS' | 'WARNING' | 'DENIED' = 'SUCCESS'
  ) => {
    setIsSimulating(true);
    setSimulationMsg(null);
    try {
      const payload = {
        timestamp: new Date().toISOString(),
        actorRole: currentRole === 'super_admin' ? 'super_admin' : currentRole,
        actorName: currentRole === 'super_admin' ? 'সুপার অ্যাডমিন (Super Admin)' : `${currentRole} Admin`,
        actorEmail: 'superadmin@baheratailunion.gov.bd',
        action,
        category,
        targetId,
        details,
        status,
        changesPayload: JSON.stringify({ simulated: true, action, targetId, timestamp: new Date().toISOString() })
      };

      // Send to server API
      const res = await fetch('/api/admin/audit-logs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      // Save to Firebase Firestore
      await saveAuditLogToFirebase(payload);

      if (res.ok) {
        const data = await res.json();
        setSimulationMsg(`অ্যাকশন সফলভাবে রেকর্ড করা হয়েছে: '${action}'`);
      } else {
        setSimulationMsg(`অ্যাকশন লোকালভিউতে রেকর্ড হয়েছে।`);
      }
      await loadAuditLogs();
    } catch (err) {
      console.error('Failed to record audit log:', err);
      setSimulationMsg('লগ সংরক্ষণে সমস্যা হয়েছে, পুনঃচেষ্টা করুন।');
    } finally {
      setIsSimulating(false);
      setTimeout(() => setSimulationMsg(null), 5000);
    }
  };

  // Clear all audit logs
  const handleClearLogs = async () => {
    if (!window.confirm('আপনি কি নিশ্চিত যে সমস্ত অডিট ট্রেইল লগ ক্লিয়ার করতে চান? এই প্রক্রিয়াটি অপরিবর্তনযোগ্য।')) {
      return;
    }
    setIsClearing(true);
    try {
      await fetch('/api/admin/audit-logs/clear', { method: 'DELETE' });
      setLogs([]);
      setSimulationMsg('সমস্ত অডিট ট্রেইল রেকর্ড ক্লিয়ার করা হয়েছে।');
    } catch (err) {
      console.error('Error clearing audit logs:', err);
    } finally {
      setIsClearing(false);
      setTimeout(() => setSimulationMsg(null), 4000);
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    if (logs.length === 0) return;
    let csv = 'Time,Role,Actor,Action,Category,Target ID,Details,Status,IP Address\n';
    logs.forEach(l => {
      const timeStr = new Date(l.timestamp).toLocaleString('bn-BD');
      csv += `"${timeStr}","${l.actorRole}","${l.actorName}","${l.action}","${l.category || ''}","${l.targetId}","${l.details.replace(/"/g, '""')}","${l.status}","${l.ipAddress || ''}"\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Audit_Trail_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export JSON
  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `Audit_Trail_Full_Export_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Filtering Logic
  const filteredLogs = logs.filter(log => {
    const matchesSearch = 
      searchTerm === '' ||
      log.actorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.targetId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.details.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = 
      selectedCategory === 'ALL' || 
      log.category === selectedCategory ||
      (selectedCategory === 'CONFIG' && log.action.includes('CONFIG')) ||
      (selectedCategory === 'USER_MANAGEMENT' && (log.action.includes('USER') || log.action.includes('ROLE'))) ||
      (selectedCategory === 'CERTIFICATE' && log.action.includes('CERT')) ||
      (selectedCategory === 'SECURITY' && (log.status === 'DENIED' || log.action.includes('SECURITY')));

    const matchesRole = 
      selectedRoleFilter === 'ALL' || 
      log.actorRole === selectedRoleFilter;

    const matchesStatus = 
      selectedStatusFilter === 'ALL' || 
      log.status === selectedStatusFilter;

    return matchesSearch && matchesCategory && matchesRole && matchesStatus;
  });

  // Calculate KPIs
  const totalLogsCount = logs.length;
  const configChangesCount = logs.filter(l => l.category === 'CONFIG' || l.action.includes('CONFIG')).length;
  const userEventsCount = logs.filter(l => l.category === 'USER_MANAGEMENT' || l.action.includes('USER') || l.action.includes('ROLE')).length;
  const certEventsCount = logs.filter(l => l.category === 'CERTIFICATE' || l.action.includes('CERT')).length;
  const securityAlertsCount = logs.filter(l => l.status === 'DENIED' || l.status === 'WARNING' || l.category === 'SECURITY').length;

  // Render relative time helper
  const getRelativeTimeStr = (isoTimestamp: string) => {
    try {
      const diffMs = Date.now() - new Date(isoTimestamp).getTime();
      const diffMins = Math.floor(diffMs / 60000);
      if (diffMins < 1) return 'এইমাত্র';
      if (diffMins < 60) return `${diffMins} মিনিট আগে`;
      const diffHours = Math.floor(diffMins / 60);
      if (diffHours < 24) return `${diffHours} ঘণ্টা আগে`;
      const diffDays = Math.floor(diffHours / 24);
      return `${diffDays} দিন আগে`;
    } catch {
      return '';
    }
  };

  // =========================================================================
  // STRICT ACCESS DENIED SCREEN (When currentRole !== 'super_admin')
  // =========================================================================
  if (currentRole !== 'super_admin') {
    return (
      <div className="space-y-6 max-w-4xl mx-auto my-8">
        {/* Security Shield Lock Barrier Header */}
        <div className="bg-gradient-to-br from-slate-900 via-rose-950 to-slate-900 text-white rounded-3xl p-8 shadow-2xl border border-rose-800/60 relative overflow-hidden text-center">
          <div className="absolute -top-12 -right-12 w-48 h-48 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col items-center justify-center space-y-4">
            <div className="w-20 h-20 rounded-2xl bg-rose-500/20 border-2 border-rose-400/40 flex items-center justify-center shadow-inner animate-pulse">
              <ShieldAlert className="w-10 h-10 text-rose-400" />
            </div>

            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-mono font-bold uppercase tracking-wider">
              <Lock className="w-3.5 h-3.5" />
              <span>Access Restricted • Class-1 Security Policy</span>
            </div>

            <h2 className="text-2xl md:text-3xl font-black text-white tracking-tight">
              অ্যাক্টিভিটি অডিট ট্রেইল প্যানেল সংরক্ষিত
            </h2>

            <p className="text-sm text-slate-300 max-w-xl leading-relaxed">
              সিস্টেমের সমস্ত প্রশাসনিক কার্যক্রম (কনফিগারেশন পরিবর্তন, ইউজার ডিলিট, সিকিউরিটি এলার্ট) পর্যবেক্ষণ ও পরিদর্শনের এই প্যানেলটি শুধুমাত্র <span className="text-amber-300 font-bold underline">super_admin</span> রোলের জন্য উন্মুক্ত। আপনার বর্তমান অ্যাক্টিভ রোল: <span className="bg-slate-800 px-2 py-0.5 rounded text-amber-300 font-mono font-bold border border-slate-700">{currentRole}</span>।
            </p>

            <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
              {onRoleChange && (
                <button
                  onClick={() => onRoleChange('super_admin')}
                  className="px-6 py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-sm rounded-xl shadow-lg hover:shadow-amber-500/20 transition-all duration-200 flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  <Sparkles className="w-4 h-4 text-slate-950 fill-slate-950" />
                  <span>'super_admin' রোলে স্যুইচ করুন</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Security Policy & Role Access Matrix Info */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Lock className="w-4 h-4 text-rose-500" />
            <span>সিকিউরিটি অডিট গাইডলাইন ও পারমিশন ম্যাট্রিক্স</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800/50">
              <span className="text-xs font-bold text-purple-900 dark:text-purple-300 block mb-1">super_admin (ফুল এক্সেস)</span>
              <p className="text-[11px] text-purple-800 dark:text-purple-400">সিস্টেমের সমস্ত অডিট ট্রেইল, কনফিগ হিস্ট্রি, ইউজার ডিলিট ও গ্লোবাল রুলস পরিচালনা।</p>
            </div>
            <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50">
              <span className="text-xs font-bold text-emerald-900 dark:text-emerald-300 block mb-1">Chairman / Secretary</span>
              <p className="text-[11px] text-emerald-800 dark:text-emerald-400">সনদপত্র অনুমোদন ও ইস্যু সংক্রান্ত কাযক্রম সম্পন্ন ও নিজস্ব ইউজার ইন্টারফেস এক্সেস।</p>
            </div>
            <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50">
              <span className="text-xs font-bold text-amber-900 dark:text-amber-300 block mb-1">UDC Operator / Citizen</span>
              <p className="text-[11px] text-amber-800 dark:text-amber-400">সনদ আবেদন প্রস্তুতকরণ, ট্র্যাকিং ও অনলাইন কপি সংগ্রহ এক্সেস।</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // MAIN SUPER_ADMIN ACTIVITY AUDIT TRAIL PANEL
  // =========================================================================
  return (
    <div className="space-y-6">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white rounded-3xl p-6 md:p-8 shadow-xl border border-emerald-800/50 relative overflow-hidden">
        <div className="absolute top-0 right-0 transform translate-x-8 -translate-y-8 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-bold flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-300" />
                <span>Super Admin Security Dashboard</span>
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-mono flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Firestore Realtime Synced</span>
              </span>
            </div>

            <h2 className="text-2xl md:text-3xl font-black text-white tracking-tight flex items-center gap-3">
              <Activity className="w-7 h-7 text-emerald-400" />
              <span>অ্যাক্টিভিটি অডিট ট্রেইল (Activity Audit Trail)</span>
            </h2>

            <p className="text-xs md:text-sm text-emerald-200/90 max-w-2xl">
              সিস্টেমে হওয়া সমস্ত প্রশাসনিক পরিবর্তন (কনফিগারেশন পরিমার্জন, ইউজার ডিলিট, সনদ অনুমোদন, ব্যাকআপ স্ন্যাপশট ও সিকিউরিটি ফ্ল্যাগ) রিয়েল-টাইমে কে এবং কখন সম্পন্ন করেছে তা পর্যবেক্ষণ প্যানেল।
            </p>
          </div>

          {/* Quick Header Actions */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={loadAuditLogs}
              disabled={isLoading}
              className="px-3.5 py-2 bg-emerald-900/80 hover:bg-emerald-800 text-emerald-100 rounded-xl border border-emerald-700/80 text-xs font-semibold flex items-center gap-2 transition cursor-pointer active:scale-95"
              title="রিফ্রেশ করুন"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-amber-300' : ''}`} />
              <span>রিফ্রেশ</span>
            </button>

            <button
              onClick={handleExportCSV}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-xl border border-slate-700 text-xs font-semibold flex items-center gap-2 transition cursor-pointer active:scale-95"
              title="CSV ফরম্যাটে রিপোর্ট ডাউনলোড করুন"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>CSV এক্সপোর্ট</span>
            </button>

            <button
              onClick={handleExportJSON}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-xl border border-slate-700 text-xs font-semibold flex items-center gap-2 transition cursor-pointer active:scale-95"
              title="সম্পূর্ণ ব্যাকআপ JSON এক্সপোর্ট"
            >
              <FileJson className="w-3.5 h-3.5 text-amber-300" />
              <span>JSON এক্সপোর্ট</span>
            </button>

            <button
              onClick={handleClearLogs}
              disabled={isClearing || logs.length === 0}
              className="px-3.5 py-2 bg-rose-950/80 hover:bg-rose-900 text-rose-200 rounded-xl border border-rose-800/80 text-xs font-semibold flex items-center gap-2 transition cursor-pointer active:scale-95 disabled:opacity-50"
              title="সমস্ত অডিট লগ মুছে ফেলুন"
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-400" />
              <span>লগ ক্লিয়ার</span>
            </button>
          </div>
        </div>
      </div>

      {/* Feedback Toast Banner */}
      {simulationMsg && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-800 dark:text-emerald-200 text-xs font-semibold flex items-center justify-between shadow-sm animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>{simulationMsg}</span>
          </div>
          <button onClick={() => setSimulationMsg(null)} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* KPI Stats Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>মোট অ্যাকশন</span>
            <Activity className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white font-mono">
            {totalLogsCount}
          </div>
          <p className="text-[11px] text-slate-500">নিবন্ধিত অডিট ইভেন্ট</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>কনফিগ পরিবর্তন</span>
            <Sliders className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          </div>
          <div className="text-2xl font-black text-purple-900 dark:text-purple-300 font-mono">
            {configChangesCount}
          </div>
          <p className="text-[11px] text-purple-700 dark:text-purple-400">মাস্টার সেটিংস আপডেট</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>ইউজার ও রোল</span>
            <UserX className="w-4 h-4 text-amber-600 dark:text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-900 dark:text-amber-300 font-mono">
            {userEventsCount}
          </div>
          <p className="text-[11px] text-amber-700 dark:text-amber-400">ডিলিট ও রোল পরিমার্জন</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>সনদ অ্যাক্টিভিটি</span>
            <FileCheck className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          </div>
          <div className="text-2xl font-black text-blue-900 dark:text-blue-300 font-mono">
            {certEventsCount}
          </div>
          <p className="text-[11px] text-blue-700 dark:text-blue-400">অনুমোদন ও বাতিলকরণ</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-1 col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>সিকিউরিটি এলার্ট</span>
            <AlertTriangle className="w-4 h-4 text-rose-600 dark:text-rose-400" />
          </div>
          <div className="text-2xl font-black text-rose-900 dark:text-rose-300 font-mono">
            {securityAlertsCount}
          </div>
          <p className="text-[11px] text-rose-700 dark:text-rose-400">সতর্কতা ও ব্যর্থ চেষ্টা</p>
        </div>
      </div>

      {/* Interactive Admin Simulation Test Toolbar */}
      <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 shadow-md space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <span className="text-xs font-bold text-amber-300 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>সুপার অ্যাডমিন সিমুলেশন টেস্ট বাটনসমূহ (Test Administrative Action Loggers):</span>
          </span>
          <span className="text-[11px] text-slate-400">১-ক্লিক টেস্ট জেনারেটর</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => handleSimulateAction('CONFIG_CHANGE', 'CONFIG', 'master_config', 'ইউনিয়ন পরিষদ চেয়ারম্যান ও ব্যাকআপ ড্রাইভ ফোল্ডার পরিবর্তন করা হয়েছে।')}
            disabled={isSimulating}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition cursor-pointer active:scale-95 flex items-center gap-1.5"
          >
            <Sliders className="w-3.5 h-3.5 text-purple-400" />
            <span>+ কনফিগ পরিবর্তন টেস্ট</span>
          </button>

          <button
            onClick={() => handleSimulateAction('USER_DELETED', 'USER_MANAGEMENT', 'usr_test_102', 'নিষ্ক্রিয় অপারেটর অ্যাকাউন্ট (usr_test_102) সম্পূর্ণ ডিলিট করা হয়েছে।', 'WARNING')}
            disabled={isSimulating}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition cursor-pointer active:scale-95 flex items-center gap-1.5"
          >
            <UserX className="w-3.5 h-3.5 text-amber-400" />
            <span>+ ইউজার ডিলিট টেস্ট</span>
          </button>

          <button
            onClick={() => handleSimulateAction('ROLE_CHANGED', 'USER_MANAGEMENT', 'usr_ctz_05', 'ইউজারের রোল Citizen হতে UDC তে পরিবর্তন করা হয়েছে।')}
            disabled={isSimulating}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition cursor-pointer active:scale-95 flex items-center gap-1.5"
          >
            <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>+ রোল পরিবর্তন টেস্ট</span>
          </button>

          <button
            onClick={() => handleSimulateAction('SECURITY_ALERT', 'SECURITY', 'auth_guard_ip', 'অপরিচিত IP (192.168.1.15) থেকে ব্যর্থ অ্যাডমিন অথেন্টিকেশন চেষ্টা।', 'DENIED')}
            disabled={isSimulating}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition cursor-pointer active:scale-95 flex items-center gap-1.5"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            <span>+ সিকিউরিটি ফ্ল্যাগ জেনারেট</span>
          </button>
        </div>
      </div>

      {/* Main Audit Trail Data Table & Filters */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 md:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="অ্যাকশন, ইউজার নাম, টার্গেট আইডি বা বিস্তারিত লিখে খুঁজুন..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Category, Role & Status Dropdowns */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Category Filter */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-700 dark:text-slate-200 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="ALL">সকল ক্যাটাগরি</option>
              <option value="CONFIG">⚙️ কনফিগারেশন (Config)</option>
              <option value="USER_MANAGEMENT">👤 ইউজার ও রোলস (User/Role)</option>
              <option value="CERTIFICATE">📜 সনদ অ্যাক্টিভিটি (Certificate)</option>
              <option value="SYSTEM">🖥️ সিস্টেম ব্যাকআপ (System)</option>
              <option value="SECURITY">🚨 সিকিউরিটি (Security)</option>
            </select>

            {/* Role Filter */}
            <select
              value={selectedRoleFilter}
              onChange={(e) => setSelectedRoleFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-700 dark:text-slate-200 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="ALL">সকল রোল</option>
              <option value="super_admin">super_admin</option>
              <option value="Developer">Developer</option>
              <option value="Chairman">Chairman</option>
              <option value="Secretary">Secretary</option>
              <option value="UDC">UDC</option>
              <option value="Citizen">Citizen</option>
            </select>

            {/* View Mode Toggle (Table / Timeline) */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <button
                onClick={() => setViewMode('table')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                  viewMode === 'table'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                টেবিল ভিউ
              </button>
              <button
                onClick={() => setViewMode('timeline')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                  viewMode === 'timeline'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                টাইমলাইন ভিউ
              </button>
            </div>
          </div>
        </div>

        {/* Results Header */}
        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-1">
          <span>প্রদর্শিত অডিট রেকর্ড: <strong className="text-slate-900 dark:text-white font-mono">{filteredLogs.length}</strong> টি (মোট: {logs.length} টি)</span>
          {filteredLogs.length !== logs.length && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('ALL');
                setSelectedRoleFilter('ALL');
                setSelectedStatusFilter('ALL');
              }}
              className="text-emerald-600 dark:text-emerald-400 hover:underline font-semibold"
            >
              ফিল্টার রিসেট করুন
            </button>
          )}
        </div>

        {/* Log Display Section */}
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-12 space-y-3">
            <RefreshCw className="w-8 h-8 text-emerald-500 animate-spin" />
            <p className="text-xs text-slate-500 dark:text-slate-400">অডিট ট্রেইল ডাটা লোড হচ্ছে...</p>
          </div>
        ) : filteredLogs.length === 0 ? (
          <div className="text-center py-12 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 space-y-3">
            <Activity className="w-10 h-10 text-slate-400 mx-auto" />
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">কোনো অডিট রেকর্ড পাওয়া যায়নি।</p>
            <p className="text-xs text-slate-500">আপনার সার্চ বা ফিল্টার ফিল্ড পরিবর্তন করে চেষ্টা করুন।</p>
          </div>
        ) : viewMode === 'table' ? (
          /* TABLE VIEW */
          <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border-b border-slate-200 dark:border-slate-700 font-bold">
                  <th className="py-3 px-3.5">সময় ও তারিখ</th>
                  <th className="py-3 px-3.5">অভিনেতা (Role & User)</th>
                  <th className="py-3 px-3.5">অ্যাকশন ও ক্যাটাগরি</th>
                  <th className="py-3 px-3.5">টার্গেট ID</th>
                  <th className="py-3 px-3.5">কার্যক্রম বিস্তারিত</th>
                  <th className="py-3 px-3.5 text-center">স্ট্যাটাস</th>
                  <th className="py-3 px-3.5 text-right">বিস্তারিত</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-800 dark:text-slate-200">
                {filteredLogs.map((log) => {
                  const relativeTime = getRelativeTimeStr(log.timestamp);
                  return (
                    <tr key={log.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                      {/* Timestamp */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        <div className="font-mono text-[11px] text-slate-900 dark:text-slate-100 font-semibold">
                          {new Date(log.timestamp).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                          <span>{new Date(log.timestamp).toLocaleDateString('bn-BD')}</span>
                          {relativeTime && <span className="text-amber-600 dark:text-amber-400 font-bold">({relativeTime})</span>}
                        </div>
                      </td>

                      {/* Actor Role & Name */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <span className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider border ${
                            log.actorRole === 'super_admin'
                              ? 'bg-purple-100 dark:bg-purple-900/40 text-purple-800 dark:text-purple-300 border-purple-300 dark:border-purple-700'
                              : log.actorRole === 'Chairman'
                              ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-800 dark:text-emerald-300 border-emerald-300 dark:border-emerald-700'
                              : log.actorRole === 'Secretary'
                              ? 'bg-blue-100 dark:bg-blue-900/40 text-blue-800 dark:text-blue-300 border-blue-300 dark:border-blue-700'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
                          }`}>
                            {log.actorRole}
                          </span>
                        </div>
                        <div className="text-xs font-bold text-slate-900 dark:text-slate-100 mt-0.5">{log.actorName}</div>
                        {log.actorEmail && <div className="text-[10px] text-slate-400">{log.actorEmail}</div>}
                      </td>

                      {/* Action */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        <span className="font-bold text-slate-900 dark:text-white font-mono text-[11px] block">
                          {log.action}
                        </span>
                        {log.category && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-medium">
                            {log.category}
                          </span>
                        )}
                      </td>

                      {/* Target ID */}
                      <td className="py-3 px-3.5 whitespace-nowrap">
                        <code className="bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded text-[11px] font-mono text-emerald-700 dark:text-emerald-400 border border-slate-200 dark:border-slate-700">
                          {log.targetId}
                        </code>
                      </td>

                      {/* Details */}
                      <td className="py-3 px-3.5 max-w-sm">
                        <p className="text-xs text-slate-700 dark:text-slate-300 line-clamp-2 leading-relaxed">
                          {log.details}
                        </p>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3.5 text-center whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                          log.status === 'SUCCESS'
                            ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-300 dark:border-emerald-700'
                            : log.status === 'WARNING'
                            ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border-amber-300 dark:border-amber-700'
                            : 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border-rose-300 dark:border-rose-700'
                        }`}>
                          {log.status === 'SUCCESS' && <CheckCircle2 className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />}
                          {log.status === 'WARNING' && <AlertTriangle className="w-3 h-3 text-amber-600 dark:text-amber-400" />}
                          {log.status === 'DENIED' && <XCircle className="w-3 h-3 text-rose-600 dark:text-rose-400" />}
                          <span>{log.status}</span>
                        </span>
                      </td>

                      {/* View Raw Payload */}
                      <td className="py-3 px-3.5 text-right whitespace-nowrap">
                        <button
                          onClick={() => setSelectedLogModal(log)}
                          className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-slate-700 dark:text-slate-300 hover:text-emerald-800 dark:hover:text-emerald-200 rounded-lg text-[11px] font-semibold transition cursor-pointer border border-slate-200 dark:border-slate-700 flex items-center gap-1 ml-auto"
                        >
                          <Eye className="w-3 h-3" />
                          <span>ইন্সপেক্ট</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          /* TIMELINE VIEW */
          <div className="relative border-l-2 border-slate-200 dark:border-slate-800 ml-4 space-y-6 py-2">
            {filteredLogs.map((log) => {
              const relativeTime = getRelativeTimeStr(log.timestamp);
              return (
                <div key={log.id} className="relative pl-6 group">
                  {/* Timeline Circle Marker */}
                  <div className={`absolute -left-3.5 top-1 w-7 h-7 rounded-full border-2 flex items-center justify-center shadow-sm ${
                    log.status === 'SUCCESS'
                      ? 'bg-emerald-500 border-white text-white'
                      : log.status === 'WARNING'
                      ? 'bg-amber-500 border-white text-white'
                      : 'bg-rose-500 border-white text-white'
                  }`}>
                    {log.category === 'CONFIG' ? <Sliders className="w-3.5 h-3.5" /> :
                     log.category === 'USER_MANAGEMENT' ? <UserX className="w-3.5 h-3.5" /> :
                     log.category === 'CERTIFICATE' ? <FileCheck className="w-3.5 h-3.5" /> :
                     log.category === 'SECURITY' ? <AlertTriangle className="w-3.5 h-3.5" /> :
                     <Activity className="w-3.5 h-3.5" />}
                  </div>

                  {/* Card Body */}
                  <div className="bg-slate-50 dark:bg-slate-800/70 rounded-2xl p-4 border border-slate-200 dark:border-slate-700/80 shadow-sm space-y-2 hover:border-emerald-500 transition">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs text-slate-900 dark:text-white">{log.action}</span>
                        <span className="text-[10px] px-2 py-0.5 bg-purple-100 dark:bg-purple-900/40 text-purple-800 dark:text-purple-300 rounded font-bold uppercase">
                          {log.actorRole}
                        </span>
                        <span className="text-xs text-slate-600 dark:text-slate-300 font-semibold">{log.actorName}</span>
                      </div>

                      <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span>{new Date(log.timestamp).toLocaleTimeString('bn-BD')}</span>
                        {relativeTime && <span className="text-amber-500 font-bold ml-1">({relativeTime})</span>}
                      </div>
                    </div>

                    <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed">
                      {log.details}
                    </p>

                    <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
                      <div className="flex items-center gap-2 font-mono text-slate-500">
                        <span>Target: <code className="text-emerald-600 dark:text-emerald-400">{log.targetId}</code></span>
                        {log.ipAddress && <span>• IP: {log.ipAddress}</span>}
                      </div>
                      <button
                        onClick={() => setSelectedLogModal(log)}
                        className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <Eye className="w-3 h-3" />
                        <span>র-পেলোড দেখুন</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* INSPECT LOG DETAILS MODAL */}
      {selectedLogModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <Activity className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-sm text-white">অডিট রেকর্ড বিস্তারিত ইন্সপেকশন (Audit Inspection)</h3>
              </div>
              <button
                onClick={() => setSelectedLogModal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3 bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">লগ আইডি</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">{selectedLogModal.id}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">টাইমস্ট্যাম্প</span>
                  <span className="font-mono text-slate-900 dark:text-white">{new Date(selectedLogModal.timestamp).toLocaleString('bn-BD')}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">অভিনেতা ও রোল</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">{selectedLogModal.actorRole} ({selectedLogModal.actorName})</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">টার্গেট রিসোর্স</span>
                  <span className="font-mono text-amber-600 dark:text-amber-400">{selectedLogModal.targetId}</span>
                </div>
              </div>

              <div>
                <span className="text-slate-500 dark:text-slate-400 font-bold block mb-1">কার্যক্রমের মূল বার্তা:</span>
                <p className="p-3 bg-slate-100 dark:bg-slate-800 rounded-xl text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                  {selectedLogModal.details}
                </p>
              </div>

              {selectedLogModal.changesPayload && (
                <div>
                  <span className="text-slate-500 dark:text-slate-400 font-bold block mb-1">র-পেলোড পে-লোড ডাটা (JSON Payload):</span>
                  <pre className="p-4 bg-slate-950 text-emerald-400 rounded-2xl font-mono text-[11px] overflow-x-auto border border-slate-800 max-h-48 leading-relaxed">
                    {(() => {
                      try {
                        return JSON.stringify(JSON.parse(selectedLogModal.changesPayload), null, 2);
                      } catch {
                        return selectedLogModal.changesPayload;
                      }
                    })()}
                  </pre>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedLogModal(null)}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
