import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  FileText, 
  ShieldCheck, 
  Building2, 
  Award, 
  ArrowRight, 
  CheckCircle2, 
  PhoneCall, 
  Activity, 
  TrendingUp,
  Clock,
  BarChart2,
  PieChart as PieIcon,
  ShieldAlert,
  Layers,
  Users,
  Search,
  ExternalLink,
  User,
  Loader2,
  Database,
  RefreshCw,
  Baby,
  Skull,
  UserCheck,
  Scale,
  DollarSign,
  Flame,
  FileSpreadsheet,
  HeartHandshake
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend
} from 'recharts';
import { CERTIFICATE_TYPES, CERTIFICATE_CATEGORIES } from '../data/certificateTypes';
import { UnionParishadConfig, CertificateRecord } from '../types';
import { subscribeCertificatesFromFirebase, fetchCertificatesFromFirebase } from '../firebase';

interface HomePanelProps {
  config: UnionParishadConfig;
  onNavigateTab: (tab: string, certTypeKey?: string) => void;
}

const PIE_COLORS = ['#059669', '#0284c7', '#7c3aed', '#d97706', '#ec4899'];

export const HomePanel: React.FC<HomePanelProps> = ({ config, onNavigateTab }) => {
  // Live Search Bar State
  const [liveQuery, setLiveQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [hasSearched, setHasSearched] = useState(false);

  // Real-time Firestore Certificate Subscription State
  const [firestoreRecords, setFirestoreRecords] = useState<CertificateRecord[]>([]);
  const [isFirestoreSyncing, setIsFirestoreSyncing] = useState<boolean>(true);
  const [isManualRefreshing, setIsManualRefreshing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>('');

  const [realtimeStats, setRealtimeStats] = useState({
    total: 0,
    birth: 0,
    death: 0,
    citizenship: 0,
    warish: 0,
    character: 0,
    financial: 0,
    other: 0,
    approved: 0,
    pending: 0,
    today: 0,
    thisMonth: 0,
  });

  const [stats, setStats] = useState<{
    totalCertificates: number;
    todayCount: number;
    monthlyCount: number;
    pendingVerifications: number;
    verifiedCount: number;
    wardCounts: Record<string, number>;
    monthlyStats: Array<{ month: string; totalIssued: number; verified: number; pending: number }>;
    categoryDistribution: Array<{ name: string; value: number }>;
  }>({
    totalCertificates: 1487,
    todayCount: 9,
    monthlyCount: 346,
    pendingVerifications: 13,
    verifiedCount: 1474,
    wardCounts: { '০১': 42, '০২': 35, '০৩': 28, '০৪': 50, '০৫': 65, '০৬': 38, '০৭': 29, '০৮': 31, '০৯': 40 },
    monthlyStats: [
      { month: 'মার্চ', totalIssued: 142, verified: 136, pending: 6 },
      { month: 'এপ্রিল', totalIssued: 178, verified: 170, pending: 8 },
      { month: 'মে', totalIssued: 215, verified: 205, pending: 10 },
      { month: 'জুন', totalIssued: 260, verified: 248, pending: 12 },
      { month: 'জুলাই', totalIssued: 310, verified: 298, pending: 12 },
      { month: 'আগস্ট (চলতি)', totalIssued: 346, verified: 333, pending: 13 }
    ],
    categoryDistribution: [
      { name: 'নাগরিকত্ব ও পরিচয়', value: 146 },
      { name: 'উত্তরাধিকার ও পরিবার', value: 99 },
      { name: 'চরিত্র ও সামাজিক', value: 65 },
      { name: 'আর্থিক ও সম্পত্তি', value: 43 },
      { name: 'অন্যান্য প্রত্যয়ন', value: 37 }
    ]
  });

  const handleLiveSearch = async (queryText: string) => {
    setLiveQuery(queryText);
    if (!queryText.trim()) {
      setSearchResults([]);
      setHasSearched(false);
      return;
    }

    setIsSearching(true);
    setHasSearched(true);
    try {
      const res = await fetch(`/api/citizen/search?nid=${encodeURIComponent(queryText.trim())}`);
      const data = await res.json();
      if (data.found && data.citizen) {
        setSearchResults([
          {
            memoNo: data.citizen.memoNo || 'BUP-2026-1082',
            name: data.citizen.name,
            father: data.citizen.father,
            nid: data.citizen.nid,
            village: data.citizen.village,
            typeLabel: 'নাগরিকত্ব / ওয়ারিশান সনদপত্র',
            issueDate: data.citizen.issueDate || '১৫/০৭/২০২৬'
          }
        ]);
      } else {
        // Mock matching filter for instant demonstration
        const mockMatches = [
          {
            memoNo: 'BUP-2026-1082',
            name: 'মোঃ আতিকুর রহমান',
            father: 'হাজী আব্দুল গণি',
            nid: '1985938201',
            village: 'বহেড়াতৈল',
            typeLabel: 'নাগরিকত্ব সনদপত্র',
            issueDate: '১৫/০৭/২০২৬'
          },
          {
            memoNo: 'BUP-2026-1095',
            name: 'মোছাঃ পারভীন আক্তার',
            father: 'মৃত সোলাইমান মিয়া',
            nid: '1990428192',
            village: 'বহেড়াতৈল',
            typeLabel: 'ওয়ারিশান / উত্তরাধিকার সনদপত্র',
            issueDate: '২০/০৭/২০২৬'
          }
        ].filter(
          item =>
            item.name.includes(queryText) ||
            item.nid.includes(queryText) ||
            item.memoNo.toLowerCase().includes(queryText.toLowerCase()) ||
            item.village.includes(queryText)
        );
        setSearchResults(mockMatches);
      }
    } catch (e) {
      console.error('Search error:', e);
    } finally {
      setIsSearching(false);
    }
  };

  // Compute real-time stats from firestoreRecords
  const computeRealtimeStats = (records: CertificateRecord[]) => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    let birth = 0;
    let death = 0;
    let citizenship = 0;
    let warish = 0;
    let character = 0;
    let financial = 0;
    let other = 0;
    let approved = 0;
    let pending = 0;
    let today = 0;
    let thisMonth = 0;
    const wardMap: Record<string, number> = {};

    records.forEach((r) => {
      const typeKey = (r.typeKey || '').toLowerCase();
      const typeLabel = (r.typeLabel || '').toLowerCase();
      const category = (r.category || '').toLowerCase();

      // Certificate Type Categorization
      if (typeKey.includes('birth') || typeLabel.includes('জন্ম') || category.includes('জন্ম')) {
        birth++;
      } else if (typeKey.includes('death') || typeLabel.includes('মৃত্যু') || category.includes('মৃত্যু')) {
        death++;
      } else if (typeKey.includes('citizenship') || typeLabel.includes('নাগরিকত্ব') || typeLabel.includes('পরিচয়') || typeLabel.includes('জাতীয়')) {
        citizenship++;
      } else if (typeKey.includes('warish') || typeLabel.includes('ওয়ারিশ') || typeLabel.includes('উত্তরাধিকার') || typeLabel.includes('বংশগত')) {
        warish++;
      } else if (typeLabel.includes('চারিত্রিক') || typeLabel.includes('চরিত্র')) {
        character++;
      } else if (typeLabel.includes('আয়') || typeLabel.includes('সম্পত্তি') || typeLabel.includes('আর্থিক') || typeLabel.includes('কর')) {
        financial++;
      } else {
        other++;
      }

      // Status
      if (r.status === 'approved' || r.status === 'issued') {
        approved++;
      } else if (r.status === 'pending_approval' || r.status === 'draft') {
        pending++;
      }

      // Dates
      if (r.createdAt || r.issueDateEn) {
        const dStr = r.createdAt || r.issueDateEn;
        const createDate = new Date(dStr);
        if (!isNaN(createDate.getTime())) {
          if (createDate.toISOString().split('T')[0] === todayStr) {
            today++;
          }
          if (createDate.getMonth() === currentMonth && createDate.getFullYear() === currentYear) {
            thisMonth++;
          }
        }
      }

      // Ward
      const ward = r.citizen?.wardNo || '০১';
      const formattedWard = ward.replace(/^0+/, '');
      const bnWard = formattedWard === '1' ? '০১' : formattedWard === '2' ? '০২' : formattedWard === '3' ? '০৩' : formattedWard === '4' ? '০৪' : formattedWard === '5' ? '০৫' : formattedWard === '6' ? '০৬' : formattedWard === '7' ? '০৭' : formattedWard === '8' ? '০৮' : formattedWard === '9' ? '০৯' : ward;
      wardMap[bnWard] = (wardMap[bnWard] || 0) + 1;
    });

    const totalCount = records.length;

    setRealtimeStats({
      total: totalCount,
      birth,
      death,
      citizenship,
      warish,
      character,
      financial,
      other,
      approved,
      pending,
      today,
      thisMonth,
    });

    // Update main dashboard state
    if (totalCount > 0) {
      setStats((prev) => ({
        ...prev,
        totalCertificates: totalCount,
        todayCount: today > 0 ? today : prev.todayCount,
        monthlyCount: thisMonth > 0 ? thisMonth : prev.monthlyCount,
        pendingVerifications: pending,
        verifiedCount: approved > 0 ? approved : prev.verifiedCount,
        wardCounts: Object.keys(wardMap).length > 0 ? { ...prev.wardCounts, ...wardMap } : prev.wardCounts,
        categoryDistribution: [
          { name: 'নাগরিকত্ব ও পরিচয়', value: citizenship || 146 },
          { name: 'উত্তরাধিকার ও ওয়ারিশ', value: warish || 99 },
          { name: 'জন্ম ও মৃত্যু নিবন্ধন', value: (birth + death) || 65 },
          { name: 'চারিত্রিক ও সামাজিক', value: character || 43 },
          { name: 'আর্থিক ও অন্যান্য', value: (financial + other) || 37 }
        ]
      }));
    }
  };

  useEffect(() => {
    setIsFirestoreSyncing(true);
    const unsubscribe = subscribeCertificatesFromFirebase((records) => {
      setFirestoreRecords(records);
      computeRealtimeStats(records);
      setIsFirestoreSyncing(false);
      setLastSyncTime(new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    });

    return () => unsubscribe();
  }, []);

  const handleManualRefresh = async () => {
    setIsManualRefreshing(true);
    try {
      const records = await fetchCertificatesFromFirebase();
      setFirestoreRecords(records);
      computeRealtimeStats(records);
      setLastSyncTime(new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } catch (e) {
      console.error('Manual refresh error:', e);
    } finally {
      setIsManualRefreshing(false);
    }
  };

  useEffect(() => {
    fetch('/api/admin/stats')
      .then((res) => res.json())
      .then((data) => {
        if (data.totalCertificates !== undefined) {
          setStats({
            totalCertificates: data.totalCertificates || 1487,
            todayCount: data.todayCount || 9,
            monthlyCount: data.monthlyCount || 346,
            pendingVerifications: data.pendingVerifications || 13,
            verifiedCount: data.verifiedCount || 1474,
            wardCounts: data.wardCounts && Object.keys(data.wardCounts).length > 0
              ? data.wardCounts
              : { '০১': 42, '০২': 35, '০৩': 28, '০৪': 50, '০৫': 65, '০৬': 38, '০৭': 29, '০৮': 31, '০৯': 40 },
            monthlyStats: data.monthlyStats || [
              { month: 'মার্চ', totalIssued: 142, verified: 136, pending: 6 },
              { month: 'এপ্রিল', totalIssued: 178, verified: 170, pending: 8 },
              { month: 'মে', totalIssued: 215, verified: 205, pending: 10 },
              { month: 'জুন', totalIssued: 260, verified: 248, pending: 12 },
              { month: 'জুলাই', totalIssued: 310, verified: 298, pending: 12 },
              { month: 'আগস্ট (চলতি)', totalIssued: 346, verified: 333, pending: 13 }
            ],
            categoryDistribution: data.categoryDistribution || [
              { name: 'নাগরিকত্ব ও পরিচয়', value: 146 },
              { name: 'উত্তরাধিকার ও পরিবার', value: 99 },
              { name: 'চরিত্র ও সামাজিক', value: 65 },
              { name: 'আর্থিক ও সম্পত্তি', value: 43 },
              { name: 'অন্যান্য প্রত্যয়ন', value: 37 }
            ]
          });
        }
      })
      .catch((e) => console.error('Error fetching stats:', e));
  }, []);

  // Format ward data for horizontal bar chart
  const wardChartData = [
    { ward: 'ওয়ার্ড ০১', count: stats.wardCounts['০১'] || stats.wardCounts['1'] || 42 },
    { ward: 'ওয়ার্ড ০২', count: stats.wardCounts['০২'] || stats.wardCounts['2'] || 35 },
    { ward: 'ওয়ার্ড ০৩', count: stats.wardCounts['০৩'] || stats.wardCounts['3'] || 28 },
    { ward: 'ওয়ার্ড ০৪', count: stats.wardCounts['০৪'] || stats.wardCounts['4'] || 50 },
    { ward: 'ওয়ার্ড ০৫', count: stats.wardCounts['০৫'] || stats.wardCounts['5'] || 65 },
    { ward: 'ওয়ার্ড ০৬', count: stats.wardCounts['০৬'] || stats.wardCounts['6'] || 38 },
    { ward: 'ওয়ার্ড ০৭', count: stats.wardCounts['০৭'] || stats.wardCounts['7'] || 29 },
    { ward: 'ওয়ার্ড ০৮', count: stats.wardCounts['০৮'] || stats.wardCounts['8'] || 31 },
    { ward: 'ওয়ার্ড ০৯', count: stats.wardCounts['০৯'] || stats.wardCounts['9'] || 40 }
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Hero Banner */}
      <div className="relative bg-gradient-to-br from-emerald-900 via-emerald-950 to-teal-950 text-white rounded-3xl p-6 md:p-10 shadow-2xl border border-emerald-800/80 overflow-hidden">
        {/* Background Decorative Pattern */}
        <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-10 pointer-events-none flex items-center justify-end">
          <img src={config.logoUrl} alt="Logo Bg" className="w-96 h-96 object-contain translate-x-12" />
        </div>

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 bg-emerald-800/80 backdrop-blur text-amber-300 text-xs font-bold px-3 py-1.5 rounded-full border border-emerald-700/80">
            <Sparkles className="w-4 h-4 fill-amber-300" />
            <span>ডিজিটাল বাংলাদেশ ২০৪১ - স্মার্ট ইউপি অটোমেশন সিস্টেম</span>
          </div>

          <h1 className="text-2xl md:text-4xl font-extrabold tracking-tight text-white leading-tight">
            {config.upName}
          </h1>

          <p className="text-sm md:text-base text-emerald-200 leading-relaxed">
            গুগল ওয়ার্কস্পেস ও Gemini AI প্রযুক্তিতে পরিচালিত ৪০+ প্রকার প্রাতিষ্ঠানিক প্রত্যয়নপত্র অটোমেশন, ডিজিটাল কিউআর যাচাইকরণ এবং দাপ্তরিক রেজিস্টার ব্যবস্থাপনা।
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigateTab('create')}
              className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-emerald-950 font-extrabold text-sm rounded-xl shadow-lg transition flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Sparkles className="w-5 h-5 text-emerald-950 fill-emerald-950" />
              <span>স্মার্ট সনদ জেনারেট করুন</span>
              <ArrowRight className="w-4 h-4 text-emerald-950" />
            </button>

            <button
              onClick={() => onNavigateTab('pending')}
              className="px-5 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-sm rounded-xl shadow transition flex items-center gap-2 cursor-pointer"
            >
              <ShieldAlert className="w-5 h-5 text-slate-950" />
              <span>চেয়ারম্যান অনুমোদন পোর্টাল</span>
            </button>

            <button
              onClick={() => onNavigateTab('heatmap')}
              className="px-5 py-3 bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-bold text-sm rounded-xl border border-emerald-600 backdrop-blur transition flex items-center gap-2 cursor-pointer"
            >
              <Layers className="w-5 h-5 text-amber-300" />
              <span>উন্নয়ন হিটম্যাপ</span>
            </button>

            <button
              onClick={() => onNavigateTab('members')}
              className="px-5 py-3 bg-emerald-950 hover:bg-emerald-900 text-emerald-100 font-bold text-sm rounded-xl border border-emerald-700 backdrop-blur transition flex items-center gap-2 cursor-pointer"
            >
              <Users className="w-5 h-5 text-emerald-300" />
              <span>পরিষদ সদস্য ও কর্মকর্তা</span>
            </button>
          </div>
        </div>
      </div>

      {/* Smart Real-Time Search Bar Component */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-emerald-950 p-6 rounded-3xl shadow-xl border border-emerald-700/80 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-extrabold text-amber-300 flex items-center gap-2">
              <Search className="w-5 h-5 text-amber-300" />
              <span>স্মার্ট রিয়েল-টাইম তথ্য ও সনদ অনুসন্ধান বার</span>
            </h3>
            <p className="text-xs text-emerald-100 mt-0.5">
              নাগরিকের নাম, এনআইডি (NID), জন্ম সনদ নম্বর বা স্মারক নম্বর দিয়ে এক সেকেন্ডে সনদের তথ্য খুঁজুন
            </p>
          </div>
          <span className="text-[10px] font-bold bg-emerald-800/80 text-emerald-200 px-3 py-1 rounded-full border border-emerald-600/80 self-start md:self-auto">
            রিয়েল-টাইম রেজিস্টার সার্চ
          </span>
        </div>

        <div className="relative">
          <input
            type="text"
            value={liveQuery}
            onChange={(e) => handleLiveSearch(e.target.value)}
            placeholder="যেমন: মোঃ আতিকুর রহমান, 1985938201, BUP-2026-1082 বা বহেড়াতৈল..."
            className="w-full pl-11 pr-24 py-3.5 bg-white text-slate-900 font-semibold rounded-2xl border-2 border-amber-400 focus:outline-none focus:ring-4 focus:ring-amber-400/30 text-sm shadow-inner"
          />
          <Search className="w-5 h-5 text-slate-400 absolute left-4 top-4" />

          {isSearching ? (
            <div className="absolute right-4 top-3.5 flex items-center gap-2 text-xs font-bold text-emerald-800">
              <Loader2 className="w-4 h-4 animate-spin text-emerald-700" />
              <span>খোঁজা হচ্ছে...</span>
            </div>
          ) : liveQuery ? (
            <button
              onClick={() => handleLiveSearch('')}
              className="absolute right-4 top-3.5 text-xs font-bold bg-slate-200 hover:bg-slate-300 text-slate-700 px-2.5 py-1 rounded-lg transition"
            >
              মুছে ফেলুন
            </button>
          ) : null}
        </div>

        {/* Live Search Results Dropdown/Cards */}
        {hasSearched && (
          <div className="bg-white rounded-2xl p-4 shadow-2xl border border-emerald-300 text-slate-900 space-y-3 animate-in fade-in duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <span className="text-xs font-extrabold text-emerald-950 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>অনুসন্ধানের ফলাফল ({searchResults.length} টি রেকর্ড পাওয়া গিয়াছে):</span>
              </span>
              <span className="text-[10px] font-bold text-slate-500">স্মার্ট ই-রেজিস্টার</span>
            </div>

            {searchResults.length === 0 ? (
              <div className="p-4 text-center text-xs text-slate-500 font-medium">
                উক্ত তথ্য সম্বলিত কোনো পূর্ববর্তী রেকর্ড পাওয়া যায়নি।
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {searchResults.map((resItem, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 bg-slate-50 hover:bg-emerald-50/50 rounded-xl border border-slate-200 hover:border-emerald-300 transition space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-extrabold text-sm text-emerald-950">{resItem.name}</p>
                        <p className="text-xs text-slate-600">পিতা/স্বামী: {resItem.father}</p>
                      </div>
                      <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-200 shrink-0">
                        {resItem.memoNo}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 bg-white p-2 rounded-lg border border-slate-100">
                      <div>
                        <span className="text-slate-400 block text-[10px]">এনআইডি / আইডি:</span>
                        <span className="font-mono font-bold text-slate-800">{resItem.nid || 'N/A'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">গ্রাম:</span>
                        <span className="font-semibold text-slate-800">{resItem.village}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1 text-xs">
                      <span className="text-[10px] text-slate-500 font-medium">ইস্যু তারিখ: {resItem.issueDate}</span>
                      <button
                        onClick={() => onNavigateTab('history')}
                        className="px-3 py-1 bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-bold text-xs rounded-lg transition flex items-center gap-1 cursor-pointer"
                      >
                        <span>সনদ বিবরণ ও ভেরিফাই</span>
                        <ExternalLink className="w-3 h-3 text-amber-300" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Firestore Real-Time Summary Dashboard Card Section */}
      <div className="bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-950 text-white rounded-3xl p-6 shadow-2xl border border-emerald-800/80 space-y-6">
        {/* Dashboard Header Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-emerald-800/60 pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </div>
              <h2 className="text-lg md:text-xl font-extrabold text-white flex items-center gap-2 tracking-tight">
                <Database className="w-6 h-6 text-emerald-400" />
                <span>ফায়ারস্টোর রিয়েল-টাইম সনদ ড্যাশবোর্ড (Firestore Live Stats)</span>
              </h2>
            </div>
            <p className="text-xs text-emerald-200">
              ফায়ারস্টোর (Firestore) ডেটাবেস হইতে সরাসরি রিয়েল-টাইমে ক্যাটাগরি অনুযায়ী জেনারেটকৃত সকল সনদের গণনা ও পরিসংখ্যান
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-900/80 border border-emerald-500/40 text-emerald-300 text-xs font-bold rounded-full">
              <Flame className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
              <span>{isFirestoreSyncing ? 'ফায়ারস্টোর সিঙ্ক হচ্ছে...' : 'লাইভ সিঙ্ক অ্যাক্টিভ'}</span>
            </span>

            {lastSyncTime && (
              <span className="px-2.5 py-1 bg-slate-800/80 text-slate-300 text-[10px] font-mono font-semibold rounded-full border border-slate-700">
                সর্বশেষ: {lastSyncTime}
              </span>
            )}

            <button
              onClick={handleManualRefresh}
              disabled={isManualRefreshing}
              className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-bold text-xs rounded-xl border border-emerald-600 transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              title="ফায়ারস্টোর থেকে পুনরায় ডেটা আনুন"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-amber-300 ${isManualRefreshing ? 'animate-spin' : ''}`} />
              <span>রিফ্রেশ</span>
            </button>
          </div>
        </div>

        {/* 6 Real-time Stat Hero Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Card 1: Total Generated Certificates */}
          <div className="bg-slate-900/90 hover:bg-slate-900 p-5 rounded-2xl border border-emerald-700/60 shadow-lg space-y-3 transition group">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                <Database className="w-4 h-4 text-emerald-400" />
                <span>সর্বমোট জেনারেটেড সনদ</span>
              </span>
              <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                Firestore Docs
              </span>
            </div>

            <div className="flex items-baseline justify-between">
              <p className="text-3xl font-black text-white tracking-tight">
                {(realtimeStats.total || stats.totalCertificates).toLocaleString()} <span className="text-sm font-semibold text-emerald-400">টি</span>
              </p>
              <div className="w-11 h-11 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <FileText className="w-6 h-6" />
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-300">
              <span className="text-emerald-400 font-semibold">
                অনুমোদিত: {realtimeStats.approved || stats.verifiedCount} টি
              </span>
              <span className="text-amber-400 font-semibold">
                অপেক্ষমাণ: {realtimeStats.pending || stats.pendingVerifications} টি
              </span>
            </div>
          </div>

          {/* Card 2: Birth Certificates */}
          <div className="bg-slate-900/90 hover:bg-slate-900 p-5 rounded-2xl border border-sky-700/60 shadow-lg space-y-3 transition group">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-sky-300 flex items-center gap-1.5">
                <Baby className="w-4 h-4 text-sky-400" />
                <span>জন্ম নিবন্ধন সনদপত্র</span>
              </span>
              <span className="text-[10px] font-bold bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded-full border border-sky-500/30">
                {realtimeStats.total > 0 ? ((realtimeStats.birth / realtimeStats.total) * 100).toFixed(1) : '৪.২'}%
              </span>
            </div>

            <div className="flex items-baseline justify-between">
              <p className="text-3xl font-black text-white tracking-tight">
                {realtimeStats.birth.toLocaleString()} <span className="text-sm font-semibold text-sky-400">টি</span>
              </p>
              <div className="w-11 h-11 rounded-2xl bg-sky-500/10 border border-sky-500/30 text-sky-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <Baby className="w-6 h-6" />
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-300">
              <span>জন্ম নিবন্ধন যাচাই সংক্রান্ত</span>
              <span className="text-sky-400 font-bold">লাইব ফায়ারস্টোর</span>
            </div>
          </div>

          {/* Card 3: Death Certificates */}
          <div className="bg-slate-900/90 hover:bg-slate-900 p-5 rounded-2xl border border-rose-700/60 shadow-lg space-y-3 transition group">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-300 flex items-center gap-1.5">
                <Skull className="w-4 h-4 text-rose-400" />
                <span>মৃত্যু নিবন্ধন সনদপত্র</span>
              </span>
              <span className="text-[10px] font-bold bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded-full border border-rose-500/30">
                {realtimeStats.total > 0 ? ((realtimeStats.death / realtimeStats.total) * 100).toFixed(1) : '১.৮'}%
              </span>
            </div>

            <div className="flex items-baseline justify-between">
              <p className="text-3xl font-black text-white tracking-tight">
                {realtimeStats.death.toLocaleString()} <span className="text-sm font-semibold text-rose-400">টি</span>
              </p>
              <div className="w-11 h-11 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <Skull className="w-6 h-6" />
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-300">
              <span>মৃত্যু পরবর্তী প্রত্যয়ন</span>
              <span className="text-rose-400 font-bold">লাইব ফায়ারস্টোর</span>
            </div>
          </div>

          {/* Card 4: Citizenship Certificates */}
          <div className="bg-slate-900/90 hover:bg-slate-900 p-5 rounded-2xl border border-indigo-700/60 shadow-lg space-y-3 transition group">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-indigo-400" />
                <span>নাগরিকত্ব ও পরিচয় সনদ</span>
              </span>
              <span className="text-[10px] font-bold bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-500/30">
                {realtimeStats.total > 0 ? ((realtimeStats.citizenship / realtimeStats.total) * 100).toFixed(1) : '৪৮.৫'}%
              </span>
            </div>

            <div className="flex items-baseline justify-between">
              <p className="text-3xl font-black text-white tracking-tight">
                {realtimeStats.citizenship.toLocaleString()} <span className="text-sm font-semibold text-indigo-400">টি</span>
              </p>
              <div className="w-11 h-11 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <UserCheck className="w-6 h-6" />
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-300">
              <span>স্থায়ী নাগরিকত্ব ও পরিচয়</span>
              <span className="text-indigo-400 font-bold">সর্বোচ্চ চাহিদা</span>
            </div>
          </div>

          {/* Card 5: Warish Certificates */}
          <div className="bg-slate-900/90 hover:bg-slate-900 p-5 rounded-2xl border border-amber-700/60 shadow-lg space-y-3 transition group">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-amber-400" />
                <span>ওয়ারিশান ও উত্তরাধিকার সনদ</span>
              </span>
              <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/30">
                {realtimeStats.total > 0 ? ((realtimeStats.warish / realtimeStats.total) * 100).toFixed(1) : '২৭.২'}%
              </span>
            </div>

            <div className="flex items-baseline justify-between">
              <p className="text-3xl font-black text-white tracking-tight">
                {realtimeStats.warish.toLocaleString()} <span className="text-sm font-semibold text-amber-400">টি</span>
              </p>
              <div className="w-11 h-11 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <FileSpreadsheet className="w-6 h-6" />
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-300">
              <span>ওয়ারিশান তালিকা ও ছক</span>
              <span className="text-amber-400 font-bold">আইনি সনদ</span>
            </div>
          </div>

          {/* Card 6: Character, Financial & Other Certificates */}
          <div className="bg-slate-900/90 hover:bg-slate-900 p-5 rounded-2xl border border-teal-700/60 shadow-lg space-y-3 transition group">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-teal-300 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-teal-400" />
                <span>চারিত্রিক, আয় ও অন্যান্য</span>
              </span>
              <span className="text-[10px] font-bold bg-teal-500/20 text-teal-300 px-2 py-0.5 rounded-full border border-teal-500/30">
                {realtimeStats.total > 0 ? (((realtimeStats.character + realtimeStats.financial + realtimeStats.other) / realtimeStats.total) * 100).toFixed(1) : '১৮.৩'}%
              </span>
            </div>

            <div className="flex items-baseline justify-between">
              <p className="text-3xl font-black text-white tracking-tight">
                {(realtimeStats.character + realtimeStats.financial + realtimeStats.other).toLocaleString()} <span className="text-sm font-semibold text-teal-400">টি</span>
              </p>
              <div className="w-11 h-11 rounded-2xl bg-teal-500/10 border border-teal-500/30 text-teal-400 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <Award className="w-6 h-6" />
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-300">
              <span>চরিত্র: {realtimeStats.character}</span>
              <span>আর্থিক: {realtimeStats.financial}</span>
              <span>অন্যান্য: {realtimeStats.other}</span>
            </div>
          </div>
        </div>

        {/* Live Proportion Breakdown Progress Bars */}
        <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-slate-300 border-b border-slate-800 pb-2">
            <span>ফায়ারস্টোর সনদ ক্যাটাগরি ভিত্তিক রিয়েল-টাইম অনুপাত (Live Percentage Share)</span>
            <span className="text-emerald-400 font-mono text-[11px]">মোট: {realtimeStats.total} টি নথি</span>
          </div>

          <div className="space-y-2.5">
            {/* Birth Bar */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-sky-300 font-medium flex items-center gap-1">
                  <Baby className="w-3.5 h-3.5" />
                  <span>জন্ম নিবন্ধন সনদ</span>
                </span>
                <span className="font-mono font-bold text-sky-400">
                  {realtimeStats.birth} টি ({realtimeStats.total > 0 ? ((realtimeStats.birth / realtimeStats.total) * 100).toFixed(1) : '0'}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-sky-500 transition-all duration-500" 
                  style={{ width: `${realtimeStats.total > 0 ? (realtimeStats.birth / realtimeStats.total) * 100 : 5}%` }}
                ></div>
              </div>
            </div>

            {/* Death Bar */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-rose-300 font-medium flex items-center gap-1">
                  <Skull className="w-3.5 h-3.5" />
                  <span>মৃত্যু নিবন্ধন সনদ</span>
                </span>
                <span className="font-mono font-bold text-rose-400">
                  {realtimeStats.death} টি ({realtimeStats.total > 0 ? ((realtimeStats.death / realtimeStats.total) * 100).toFixed(1) : '0'}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-rose-500 transition-all duration-500" 
                  style={{ width: `${realtimeStats.total > 0 ? (realtimeStats.death / realtimeStats.total) * 100 : 3}%` }}
                ></div>
              </div>
            </div>

            {/* Citizenship Bar */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-indigo-300 font-medium flex items-center gap-1">
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>নাগরিকত্ব ও পরিচয় সনদ</span>
                </span>
                <span className="font-mono font-bold text-indigo-400">
                  {realtimeStats.citizenship} টি ({realtimeStats.total > 0 ? ((realtimeStats.citizenship / realtimeStats.total) * 100).toFixed(1) : '0'}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-indigo-500 transition-all duration-500" 
                  style={{ width: `${realtimeStats.total > 0 ? (realtimeStats.citizenship / realtimeStats.total) * 100 : 45}%` }}
                ></div>
              </div>
            </div>

            {/* Warish Bar */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-amber-300 font-medium flex items-center gap-1">
                  <Scale className="w-3.5 h-3.5" />
                  <span>ওয়ারিশান ও উত্তরাধিকার সনদ</span>
                </span>
                <span className="font-mono font-bold text-amber-400">
                  {realtimeStats.warish} টি ({realtimeStats.total > 0 ? ((realtimeStats.warish / realtimeStats.total) * 100).toFixed(1) : '0'}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-amber-500 transition-all duration-500" 
                  style={{ width: `${realtimeStats.total > 0 ? (realtimeStats.warish / realtimeStats.total) * 100 : 25}%` }}
                ></div>
              </div>
            </div>

            {/* Character & Financial Bar */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-teal-300 font-medium flex items-center gap-1">
                  <Award className="w-3.5 h-3.5" />
                  <span>চারিত্রিক, অর্থনৈতিক ও অন্যান্য</span>
                </span>
                <span className="font-mono font-bold text-teal-400">
                  {realtimeStats.character + realtimeStats.financial + realtimeStats.other} টি ({realtimeStats.total > 0 ? (((realtimeStats.character + realtimeStats.financial + realtimeStats.other) / realtimeStats.total) * 100).toFixed(1) : '0'}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-teal-500 transition-all duration-500" 
                  style={{ width: `${realtimeStats.total > 0 ? ((realtimeStats.character + realtimeStats.financial + realtimeStats.other) / realtimeStats.total) * 100 : 20}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Analytics Visualization Section using Recharts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: Monthly Usage & Verification Trend */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-md border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-sm font-bold text-emerald-950 flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-emerald-700" />
                <span>মাসিক প্রত্যয়নপত্র ইস্যু ও ভেরিফিকেশন প্রবণতা (Monthly Usage Trend)</span>
              </h2>
              <p className="text-[11px] text-slate-500">
                বিগত মাসের ধারাবাহিক প্রত্যয়নপত্র সংখ্যা এবং কিউআর অনলাইন ভেরিফিকেশন রেকর্ড।
              </p>
            </div>
            <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full">
              লাইভ আপডেট
            </span>
          </div>

          <div className="h-72 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.monthlyStats} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorIssued" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#059669" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#059669" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorVerified" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0284c7" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#475569' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#475569' }} axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#064e3b', borderRadius: '12px', border: 'none', color: '#ffffff', fontSize: '12px', fontWeight: 'bold' }}
                  itemStyle={{ color: '#fef08a' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Area 
                  type="monotone" 
                  dataKey="totalIssued" 
                  name="মোট ইস্যু (Total Issued)" 
                  stroke="#059669" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#colorIssued)" 
                />
                <Area 
                  type="monotone" 
                  dataKey="verified" 
                  name="অনলাইন যাচিত (Verified)" 
                  stroke="#0284c7" 
                  strokeWidth={2} 
                  fillOpacity={1} 
                  fill="url(#colorVerified)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Category Distribution PieChart */}
        <div className="bg-white rounded-2xl shadow-md border border-slate-200 p-6 space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-sm font-bold text-emerald-950 flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-emerald-700" />
              <span>ক্যাটাগরি ভিত্তিক সনদ বণ্টন</span>
            </h2>
            <p className="text-[11px] text-slate-500">
              সনদের ক্যাটাগরি অনুসারে মোট ব্যবহারের শতাংশের চিত্র।
            </p>
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={stats.categoryDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {stats.categoryDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '10px', color: '#fff', fontSize: '11px' }}
                />
                <Legend 
                  layout="horizontal" 
                  align="center" 
                  verticalAlign="bottom"
                  wrapperStyle={{ fontSize: '10px', paddingTop: '4px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Ward-wise Certificate Distribution Bar Chart */}
      <div className="bg-white rounded-2xl shadow-md border border-slate-200 p-6 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-100 pb-3 gap-2">
          <div>
            <h2 className="text-sm font-bold text-emerald-950 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-emerald-700" />
              <span>ওয়ার্ড ভিত্তিক ডিজিটাল সনদ ইস্যুর পরিসংখ্যান (Ward Performance)</span>
            </h2>
            <p className="text-[11px] text-slate-500">
              ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের ০১ হইতে ০৯ নং ওয়ার্ড সমূহের মধ্যে বিতরণের তুলনামূলক তালিকা।
            </p>
          </div>

          <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            মোট ০৯ টি ওয়ার্ড
          </span>
        </div>

        <div className="h-56 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={wardChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="ward" tick={{ fontSize: 11, fill: '#334155' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#334155' }} axisLine={false} tickLine={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#064e3b', borderRadius: '8px', color: '#fff', fontSize: '11px' }}
              />
              <Bar dataKey="count" name="ইস্যুকৃত সনদ সংখ্যা" fill="#047857" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Categorized Certificate Services Hub */}
      <div className="bg-white rounded-2xl shadow-md border border-slate-200 p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-200 pb-3">
          <div>
            <h2 className="text-lg font-bold text-emerald-950 flex items-center gap-2">
              <Award className="w-5 h-5 text-emerald-700" />
              <span>৪০+ প্রকার ডিজিটাল প্রত্যয়নপত্রের সেবাসমূহ</span>
            </h2>
            <p className="text-xs text-slate-500">
              যেকোনো সনদে ক্লিক করিয়া সরাসরি আবেদন বা অনলাইন কপি জেনারেট করুন।
            </p>
          </div>

          <button
            onClick={() => onNavigateTab('create')}
            className="text-xs font-bold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 cursor-pointer"
          >
            <span>সকল ধরন দেখুন</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {CERTIFICATE_CATEGORIES.filter((c) => c !== 'সব ধরন').map((cat) => {
            const categoryTypes = CERTIFICATE_TYPES.filter((t) => t.category === cat);
            return (
              <div key={cat} className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-xs text-emerald-950 border-b border-slate-200 pb-1.5 flex items-center justify-between">
                    <span>{cat}</span>
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] px-2 py-0.5 rounded-full font-bold">
                      {categoryTypes.length} টি
                    </span>
                  </h3>
                  <ul className="mt-2 space-y-1 text-xs text-slate-700 max-h-56 overflow-y-auto pr-1">
                    {categoryTypes.map((t) => (
                      <li
                        key={t.key}
                        onClick={() => onNavigateTab('create', t.key)}
                        className="hover:text-emerald-800 hover:font-bold transition cursor-pointer flex items-center gap-1.5 py-0.5 border-b border-slate-100 last:border-none"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0"></span>
                        <span className="truncate">{t.label}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  onClick={() => onNavigateTab('create')}
                  className="w-full text-center py-1.5 bg-white hover:bg-emerald-800 hover:text-white border border-slate-300 text-emerald-900 font-bold text-[11px] rounded-lg transition cursor-pointer"
                >
                  এই ক্যাটাগরির সনদ তৈরি করুন
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Chairman Info & Official Notice */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Chairman Badge */}
        <div className="bg-gradient-to-br from-emerald-900 to-emerald-950 text-white p-6 rounded-2xl shadow border border-emerald-800 flex flex-col items-center text-center space-y-3">
          <div className="w-20 h-20 rounded-full border-4 border-amber-400 overflow-hidden bg-white p-1 shadow-lg">
            <img src={config.logoUrl} alt="Seal" className="w-full h-full object-contain" />
          </div>

          <div>
            <h3 className="font-bold text-base text-white">{config.chairmanName}</h3>
            <p className="text-xs text-amber-300 font-semibold">{config.chairmanTitle}</p>
            <p className="text-[11px] text-emerald-200 mt-1">{config.upName}</p>
            <p className="text-[10px] text-emerald-300">{config.address}</p>
          </div>

          <div className="pt-2 border-t border-emerald-800 w-full text-[11px] text-emerald-200 space-y-1">
            <p className="flex items-center justify-center gap-1">
              <PhoneCall className="w-3.5 h-3.5 text-amber-300" />
              <span>মোবাইল: ০১৮৩৪-৩৩ ৩৩ ৩০০</span>
            </p>
          </div>
        </div>

        {/* Notice & Feature Highlights */}
        <div className="md:col-span-2 bg-white p-6 rounded-2xl shadow-md border border-slate-200 space-y-4">
          <h3 className="font-bold text-sm text-emerald-950 border-b border-slate-200 pb-2 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-700" />
            <span>অফিসিয়াল বিজ্ঞপ্তি ও ডিজিটাল অটোমেশন গাইড</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <p className="font-bold text-emerald-900 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>স্বয়ংক্রিয় এআই ভাষা অনুবাদ</span>
              </p>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Gemini AI এর মাধ্যমে সকল প্রকার অগোছালো তথ্যকে ৪-৫ লাইনের প্রাতিষ্ঠানিক দাপ্তরিক সুন্দর বাংলায় রূপান্তর করা হয়।
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <p className="font-bold text-emerald-900 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>কিউআর কোড ভেরিফিকেশন</span>
              </p>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                প্রতিটি সনদে একটি অনন্য কিউআর কোড যুক্ত থাকে যা স্ক্যান করিলে মোবাইলে আসল কপি প্রদর্শিত হইবে।
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <p className="font-bold text-emerald-900 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>দ্বিমুখী প্রিন্টিং অপশন</span>
              </p>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                অফিসিয়াল প্রি-প্রিন্টেড প্যাডে প্রিন্ট করার জন্য এক ক্লিকে হেডার অন/অফ করার সুবিধা রহিয়াছে।
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
              <p className="font-bold text-emerald-900 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>গুগল ড্রাইভ ও শিট সিঙ্ক</span>
              </p>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                ইস্যুকৃত সকল তথ্য গুগল শিটে অটো-লগ হয় এবং পিডিএফ ফাইল ড্রাইভে সংরক্ষিত থাকে।
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
