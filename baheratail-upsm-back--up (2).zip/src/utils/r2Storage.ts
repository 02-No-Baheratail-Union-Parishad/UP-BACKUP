import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';

export interface R2Config {
  accessKeyId: string;
  secretAccessKey: string;
  endpoint: string;
  bucketName: string;
  publicDomain?: string;
}

let s3ClientInstance: S3Client | null = null;

/**
 * Retrieves the R2 S3 client, initializing lazily.
 */
export function getR2Client(): { client: S3Client; config: R2Config } {
  const accessKeyId =
    process.env.R2_ACCESS_KEY_ID ||
    process.env.CLOUDFLARE_R2_ACCESS_KEY_ID ||
    process.env.AWS_ACCESS_KEY_ID ||
    '26d4ea0bfd548258646061ba6d80d57d';

  const secretAccessKey =
    process.env.R2_SECRET_ACCESS_KEY ||
    process.env.CLOUDFLARE_R2_SECRET_ACCESS_KEY ||
    process.env.AWS_SECRET_ACCESS_KEY ||
    'b4c85f0e7c2937703376d89fb7d2a880cb2aa00631fcb8c32c8aa3d6612db94f';

  const endpoint =
    process.env.R2_ENDPOINT ||
    process.env.CLOUDFLARE_R2_ENDPOINT ||
    'https://8145fd7882d729f182b85e7c18c1a5f0.r2.cloudflarestorage.com';

  const bucketName =
    process.env.R2_BUCKET_NAME ||
    process.env.CLOUDFLARE_R2_BUCKET_NAME ||
    'baheratail-up-certificates';

  const publicDomain =
    process.env.R2_PUBLIC_DOMAIN ||
    process.env.CLOUDFLARE_R2_PUBLIC_DOMAIN;

  if (!accessKeyId || !secretAccessKey || !endpoint) {
    throw new Error(
      'Cloudflare R2 credentials (R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_ENDPOINT) are not fully configured in environment variables.'
    );
  }

  if (!s3ClientInstance) {
    s3ClientInstance = new S3Client({
      region: 'auto',
      endpoint: endpoint,
      credentials: {
        accessKeyId,
        secretAccessKey,
      },
    });
  }

  return {
    client: s3ClientInstance,
    config: {
      accessKeyId,
      secretAccessKey,
      endpoint,
      bucketName,
      publicDomain,
    },
  };
}

/**
 * Checks if Cloudflare R2 credentials are set in environment variables.
 */
export function isR2Configured(): boolean {
  try {
    const accessKeyId =
      process.env.R2_ACCESS_KEY_ID ||
      process.env.CLOUDFLARE_R2_ACCESS_KEY_ID ||
      process.env.AWS_ACCESS_KEY_ID ||
      '26d4ea0bfd548258646061ba6d80d57d';
    const secretAccessKey =
      process.env.R2_SECRET_ACCESS_KEY ||
      process.env.CLOUDFLARE_R2_SECRET_ACCESS_KEY ||
      process.env.AWS_SECRET_ACCESS_KEY ||
      'b4c85f0e7c2937703376d89fb7d2a880cb2aa00631fcb8c32c8aa3d6612db94f';
    const endpoint =
      process.env.R2_ENDPOINT ||
      process.env.CLOUDFLARE_R2_ENDPOINT ||
      'https://8145fd7882d729f182b85e7c18c1a5f0.r2.cloudflarestorage.com';

    return Boolean(accessKeyId && secretAccessKey && endpoint);
  } catch {
    return false;
  }
}

/**
 * Constructs the permanent public URL for an object stored in Cloudflare R2.
 */
export function getR2PublicUrl(key: string, customConfig?: Partial<R2Config>): string {
  const bucketName =
    customConfig?.bucketName ||
    process.env.R2_BUCKET_NAME ||
    process.env.CLOUDFLARE_R2_BUCKET_NAME ||
    'baheratail-up-certificates';

  const publicDomain =
    customConfig?.publicDomain ||
    process.env.R2_PUBLIC_DOMAIN ||
    process.env.CLOUDFLARE_R2_PUBLIC_DOMAIN;

  const cleanKey = key.replace(/^\/+/, '');

  if (publicDomain) {
    const domain = publicDomain.endsWith('/') ? publicDomain.slice(0, -1) : publicDomain;
    return `${domain}/${cleanKey}`;
  }

  const endpoint =
    customConfig?.endpoint ||
    process.env.R2_ENDPOINT ||
    process.env.CLOUDFLARE_R2_ENDPOINT ||
    'https://baheratailup.r2.cloudflarestorage.com';

  const cleanEndpoint = endpoint.replace(/\/+$/, '');
  return `${cleanEndpoint}/${bucketName}/${cleanKey}`;
}

/**
 * Uploads a certificate file/blob to Cloudflare R2 storage using AWS SDK v3 S3 client.
 * @param blob - The certificate file content as a Blob, Buffer, Uint8Array, or ArrayBuffer
 * @param fileName - The desired file name or key in Cloudflare R2 (e.g. "cert-2026-001.pdf")
 * @param contentType - Optional MIME type (defaults to application/pdf)
 * @returns The permanent public URL of the uploaded certificate
 */
export async function uploadCertificateToR2(
  blob: Blob | Buffer | Uint8Array | ArrayBuffer,
  fileName: string,
  contentType: string = 'application/pdf'
): Promise<string> {
  const { client, config } = getR2Client();

  let bodyData: Uint8Array;

  if (typeof Blob !== 'undefined' && blob instanceof Blob) {
    const arrayBuffer = await blob.arrayBuffer();
    bodyData = new Uint8Array(arrayBuffer);
    if (!contentType && blob.type) {
      contentType = blob.type;
    }
  } else if (blob instanceof ArrayBuffer) {
    bodyData = new Uint8Array(blob);
  } else if (blob instanceof Uint8Array) {
    bodyData = blob;
  } else if (typeof Buffer !== 'undefined' && Buffer.isBuffer(blob)) {
    bodyData = new Uint8Array(blob);
  } else {
    throw new Error('Invalid or unsupported blob format provided for R2 upload.');
  }

  // Ensure clean, organized key prefix
  const sanitizedFileName = fileName.replace(/^\/+/, '');
  const key = sanitizedFileName.startsWith('certificates/')
    ? sanitizedFileName
    : `certificates/${sanitizedFileName}`;

  const command = new PutObjectCommand({
    Bucket: config.bucketName,
    Key: key,
    Body: bodyData,
    ContentType: contentType,
    CacheControl: 'max-age=31536000',
  });

  await client.send(command);

  return getR2PublicUrl(key, config);
}

/**
 * Deletes a certificate file from Cloudflare R2 storage.
 * @param fileName - The file key/name in Cloudflare R2
 */
export async function deleteCertificateFromR2(fileName: string): Promise<boolean> {
  try {
    const { client, config } = getR2Client();
    const cleanKey = fileName.replace(/^\/+/, '');
    const key = cleanKey.startsWith('certificates/') ? cleanKey : `certificates/${cleanKey}`;

    const command = new DeleteObjectCommand({
      Bucket: config.bucketName,
      Key: key,
    });

    await client.send(command);
    return true;
  } catch (error) {
    console.error('Failed to delete object from Cloudflare R2:', error);
    return false;
  }
}
