import { logErrorToAudit } from '../firebase';

let currentUserRole = 'Citizen';

/**
 * Sets the active user role for contextual error logging.
 */
export function setErrorLoggerUserRole(role: string) {
  if (role) {
    currentUserRole = role;
  }
}

/**
 * Manually logs a captured exception or error message to audit_logs in Firestore.
 */
export async function logCapturedError(
  error: Error | string | unknown,
  contextMessage?: string
): Promise<string | null> {
  const errorDetails =
    typeof error === 'string'
      ? error
      : error instanceof Error
      ? error.message
      : JSON.stringify(error);

  const stackTrace = error instanceof Error ? error.stack || '' : '';
  const fullDetails = contextMessage ? `[${contextMessage}] ${errorDetails}` : errorDetails;

  return logErrorToAudit(fullDetails, currentUserRole, stackTrace);
}

/**
 * Initializes global event listeners to catch unhandled errors and promise rejections.
 */
export function initCentralizedErrorLogging() {
  if (typeof window === 'undefined') return;

  // Catch unhandled runtime errors
  window.addEventListener('error', (event: ErrorEvent) => {
    const message = event.message || 'Unhandled Window Exception';
    const stack = event.error?.stack || `${event.filename}:${event.lineno}:${event.colno}`;
    logErrorToAudit(`[Global Exception] ${message}`, currentUserRole, stack);
  });

  // Catch unhandled promise rejections
  window.addEventListener('unhandledrejection', (event: PromiseRejectionEvent) => {
    const reason = event.reason;
    const errorDetails =
      reason instanceof Error
        ? reason.message
        : typeof reason === 'string'
        ? reason
        : JSON.stringify(reason);
    const stack = reason instanceof Error ? reason.stack || '' : '';
    logErrorToAudit(`[Unhandled Rejection] ${errorDetails}`, currentUserRole, stack);
  });
}
