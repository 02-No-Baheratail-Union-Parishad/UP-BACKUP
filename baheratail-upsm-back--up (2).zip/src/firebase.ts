import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  addDoc, 
  query, 
  where, 
  orderBy, 
  deleteDoc,
  onSnapshot,
  serverTimestamp,
  writeBatch
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { CertificateRecord, UnionParishadConfig, AuditLogEntry } from './types';

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore with specific database ID if present
export const db = firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)'
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

const CERTIFICATES_COLLECTION = 'certificates';
const CONFIGS_COLLECTION = 'configs';
const MASTER_CONFIG_DOC = 'master_config';

// Initialize Firestore Collections and Service functions
export async function saveCertificateToFirebase(record: CertificateRecord): Promise<string> {
  try {
    const docId = record.memoNo.replace(/[^a-zA-Z0-9.-]/g, '_') || `cert_${Date.now()}`;
    const docRef = doc(db, CERTIFICATES_COLLECTION, docId);
    
    const cleanData = JSON.parse(JSON.stringify(record));
    await setDoc(docRef, {
      ...cleanData,
      updatedAt: new Date().toISOString(),
      timestamp: serverTimestamp()
    }, { merge: true });
    
    return docId;
  } catch (error) {
    console.error('Error saving certificate to Firebase:', error);
    throw error;
  }
}

/**
 * Batch write operation to restore historical records into Firestore in chunks of up to 400 records.
 */
export async function batchRestoreCertificatesToFirebase(records: CertificateRecord[]): Promise<{ count: number; batches: number }> {
  try {
    if (!Array.isArray(records) || records.length === 0) {
      return { count: 0, batches: 0 };
    }

    const BATCH_SIZE = 400; // Safe threshold under Firestore 500 writes limit per batch
    let totalRestored = 0;
    let batchCount = 0;

    for (let i = 0; i < records.length; i += BATCH_SIZE) {
      const chunk = records.slice(i, i + BATCH_SIZE);
      const batch = writeBatch(db);

      for (const record of chunk) {
        if (!record || !record.memoNo) continue;
        const docId = record.memoNo.replace(/[^a-zA-Z0-9.-]/g, '_') || `cert_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        const docRef = doc(db, CERTIFICATES_COLLECTION, docId);
        const cleanData = JSON.parse(JSON.stringify(record));
        batch.set(docRef, {
          ...cleanData,
          updatedAt: new Date().toISOString(),
          timestamp: serverTimestamp()
        }, { merge: true });
        totalRestored++;
      }

      await batch.commit();
      batchCount++;
    }

    return { count: totalRestored, batches: batchCount };
  } catch (error) {
    console.error('Error batch restoring certificates to Firestore:', error);
    throw error;
  }
}

export async function fetchCertificatesFromFirebase(): Promise<CertificateRecord[]> {
  try {
    const colRef = collection(db, CERTIFICATES_COLLECTION);
    const snapshot = await getDocs(colRef);
    const records: CertificateRecord[] = [];
    
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      if (data.memoNo) {
        records.push(data as CertificateRecord);
      }
    });
    
    return records;
  } catch (error) {
    console.error('Error fetching certificates from Firebase:', error);
    return [];
  }
}

export function subscribeCertificatesFromFirebase(callback: (records: CertificateRecord[]) => void): () => void {
  try {
    const colRef = collection(db, CERTIFICATES_COLLECTION);
    return onSnapshot(colRef, (snapshot) => {
      const records: CertificateRecord[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        if (data.memoNo) {
          records.push(data as CertificateRecord);
        }
      });
      callback(records);
    }, (error) => {
      console.warn('Certificates real-time subscription warning:', error);
    });
  } catch (error) {
    console.warn('Certificates real-time subscription failed:', error);
    return () => {};
  }
}

export async function searchCertificateInFirebase(queryStr: string): Promise<CertificateRecord | null> {
  try {
    const trimmed = queryStr.trim();
    if (!trimmed) return null;

    // Search by exact memoNo first
    const colRef = collection(db, CERTIFICATES_COLLECTION);
    const qMemo = query(colRef, where('memoNo', '==', trimmed));
    const memoSnap = await getDocs(qMemo);
    
    if (!memoSnap.empty) {
      const data = memoSnap.docs[0].data();
      return data as CertificateRecord;
    }

    // Search by NID
    const qNid = query(colRef, where('citizen.nid', '==', trimmed));
    const nidSnap = await getDocs(qNid);
    
    if (!nidSnap.empty) {
      const data = nidSnap.docs[0].data();
      return data as CertificateRecord;
    }

    // Client-side fallback check in all docs
    const allRecords = await fetchCertificatesFromFirebase();
    return allRecords.find(r => 
      r.memoNo.toLowerCase() === trimmed.toLowerCase() || 
      (r.citizen && (r.citizen.nid === trimmed || r.citizen.birthNo === trimmed))
    ) || null;
  } catch (error) {
    console.error('Error searching certificate in Firebase:', error);
    return null;
  }
}

export async function saveConfigToFirebase(config: UnionParishadConfig): Promise<void> {
  try {
    const docRef = doc(db, CONFIGS_COLLECTION, MASTER_CONFIG_DOC);
    await setDoc(docRef, JSON.parse(JSON.stringify(config)), { merge: true });
  } catch (error) {
    console.error('Error saving config to Firebase:', error);
  }
}

export async function fetchConfigFromFirebase(): Promise<UnionParishadConfig | null> {
  try {
    const docRef = doc(db, CONFIGS_COLLECTION, MASTER_CONFIG_DOC);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as UnionParishadConfig;
    }
    return null;
  } catch (error) {
    console.error('Error fetching config from Firebase:', error);
    return null;
  }
}

export async function fetchPendingCertificatesCountFromFirebase(): Promise<number> {
  try {
    const colRef = collection(db, CERTIFICATES_COLLECTION);
    const snapshot = await getDocs(colRef);
    let count = 0;
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      if (data.status === 'pending_approval' || data.status === 'draft') {
        count++;
      }
    });
    return count;
  } catch (error) {
    console.error('Error fetching pending count from Firestore:', error);
    return 0;
  }
}

export function subscribePendingCertificatesCount(callback: (count: number) => void): () => void {
  try {
    const colRef = collection(db, CERTIFICATES_COLLECTION);
    return onSnapshot(colRef, (snapshot) => {
      let count = 0;
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        if (data.status === 'pending_approval' || data.status === 'draft') {
          count++;
        }
      });
      callback(count);
    }, (error) => {
      console.warn('Firestore subscription warning:', error);
    });
  } catch (error) {
    console.warn('Firestore subscription failed:', error);
    return () => {};
  }
}

/**
 * Logs frontend runtime errors into the 'audit_logs' Firestore collection.
 */
export async function logErrorToAudit(
  errorDetails: string,
  userRole: string = 'Citizen',
  stackTrace: string = ''
): Promise<string | null> {
  try {
    const colRef = collection(db, 'audit_logs');
    const docRef = await addDoc(colRef, {
      timestamp: new Date().toISOString(),
      errorDetails,
      userRole,
      stackTrace,
      actorRole: userRole,
      actorName: 'System Monitor',
      action: 'SYSTEM_ERROR',
      targetId: 'frontend_exception',
      details: errorDetails,
      status: 'WARNING',
      createdAt: serverTimestamp()
    });
    return docRef.id;
  } catch (err) {
    console.error('Failed to log error to audit_logs collection:', err);
    return null;
  }
}

/**
 * Saves an administrative or system action entry into the 'system_audit' Firestore collection.
 */
export async function saveSystemAuditLogToFirebase(logEntry: Omit<AuditLogEntry, 'id'>): Promise<string> {
  try {
    const colRef = collection(db, 'system_audit');
    const docRef = await addDoc(colRef, {
      ...logEntry,
      timestamp: logEntry.timestamp || new Date().toISOString(),
      createdAt: serverTimestamp()
    });
    return docRef.id;
  } catch (error) {
    console.error('Error saving audit log to system_audit in Firebase:', error);
    throw error;
  }
}

/**
 * Fetches all system audit log entries from the 'system_audit' Firestore collection.
 */
export async function fetchSystemAuditLogsFromFirebase(): Promise<AuditLogEntry[]> {
  try {
    const systemAuditRef = collection(db, 'system_audit');
    const snapshot = await getDocs(systemAuditRef);
    const logs: AuditLogEntry[] = [];
    
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      logs.push({
        id: docSnap.id,
        timestamp: data.timestamp || new Date().toISOString(),
        actorRole: data.actorRole || data.userRole || 'super_admin',
        actorName: data.actorName || 'সুপার অ্যাডমিন',
        actorEmail: data.actorEmail || 'superadmin@baheratailunion.gov.bd',
        action: data.action || 'SYSTEM_ACTION',
        category: data.category || 'SYSTEM',
        targetId: data.targetId || 'system_resource',
        details: data.details || data.errorDetails || '',
        ipAddress: data.ipAddress,
        changesPayload: data.changesPayload,
        status: data.status || 'SUCCESS'
      });
    });

    // Also attempt fetching from 'audit_logs' if system_audit yields few records so all logs show up
    if (logs.length < 5) {
      const auditLogsRef = collection(db, 'audit_logs');
      const auditSnapshot = await getDocs(auditLogsRef);
      auditSnapshot.forEach((docSnap) => {
        if (!logs.some(l => l.id === docSnap.id)) {
          const data = docSnap.data();
          logs.push({
            id: docSnap.id,
            timestamp: data.timestamp || new Date().toISOString(),
            actorRole: data.actorRole || data.userRole || 'super_admin',
            actorName: data.actorName || 'সিস্টেম অ্যাডমিন',
            actorEmail: data.actorEmail,
            action: data.action || 'ADMIN_ACTION',
            category: data.category || 'SYSTEM',
            targetId: data.targetId || 'system',
            details: data.details || data.errorDetails || '',
            ipAddress: data.ipAddress,
            changesPayload: data.changesPayload,
            status: data.status || 'SUCCESS'
          });
        }
      });
    }

    return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  } catch (error) {
    console.error('Error fetching logs from system_audit in Firebase:', error);
    return [];
  }
}

/**
 * Real-time subscription for system audit log entries from the 'system_audit' Firestore collection.
 */
export function subscribeSystemAuditLogsFromFirebase(callback: (logs: AuditLogEntry[]) => void): () => void {
  try {
    const colRef = collection(db, 'system_audit');
    return onSnapshot(colRef, (snapshot) => {
      const logs: AuditLogEntry[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        logs.push({
          id: docSnap.id,
          timestamp: data.timestamp || new Date().toISOString(),
          actorRole: data.actorRole || data.userRole || 'super_admin',
          actorName: data.actorName || 'সুপার অ্যাডমিন',
          actorEmail: data.actorEmail || 'superadmin@baheratailunion.gov.bd',
          action: data.action || 'SYSTEM_ACTION',
          category: data.category || 'SYSTEM',
          targetId: data.targetId || 'system_resource',
          details: data.details || data.errorDetails || '',
          ipAddress: data.ipAddress,
          changesPayload: data.changesPayload,
          status: data.status || 'SUCCESS'
        });
      });
      logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      callback(logs);
    }, (error) => {
      console.warn('system_audit real-time subscription warning:', error);
    });
  } catch (error) {
    console.warn('system_audit subscription failed:', error);
    return () => {};
  }
}

/**
 * Saves an administrative action entry into the 'audit_logs' Firestore collection.
 */
export async function saveAuditLogToFirebase(logEntry: Omit<AuditLogEntry, 'id'>): Promise<string> {
  try {
    const colRef = collection(db, 'audit_logs');
    const docRef = await addDoc(colRef, {
      ...logEntry,
      timestamp: logEntry.timestamp || new Date().toISOString(),
      createdAt: serverTimestamp()
    });
    return docRef.id;
  } catch (error) {
    console.error('Error saving audit log to Firebase:', error);
    throw error;
  }
}

/**
 * Fetches all audit log entries from Firestore.
 */
export async function fetchAuditLogsFromFirebase(): Promise<AuditLogEntry[]> {
  try {
    const colRef = collection(db, 'audit_logs');
    const snapshot = await getDocs(colRef);
    const logs: AuditLogEntry[] = [];
    
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      logs.push({
        id: docSnap.id,
        timestamp: data.timestamp || new Date().toISOString(),
        actorRole: data.actorRole || data.userRole || 'super_admin',
        actorName: data.actorName || 'সিস্টেম এডমিন',
        actorEmail: data.actorEmail,
        action: data.action || 'ADMIN_ACTION',
        category: data.category || 'SYSTEM',
        targetId: data.targetId || 'system',
        details: data.details || data.errorDetails || '',
        ipAddress: data.ipAddress,
        changesPayload: data.changesPayload,
        status: data.status || 'SUCCESS'
      });
    });

    return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  } catch (error) {
    console.error('Error fetching audit logs from Firebase:', error);
    return [];
  }
}

/**
 * Real-time subscription for audit log entries from Firestore.
 */
export function subscribeAuditLogsFromFirebase(callback: (logs: AuditLogEntry[]) => void): () => void {
  try {
    const colRef = collection(db, 'audit_logs');
    return onSnapshot(colRef, (snapshot) => {
      const logs: AuditLogEntry[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        logs.push({
          id: docSnap.id,
          timestamp: data.timestamp || new Date().toISOString(),
          actorRole: data.actorRole || data.userRole || 'super_admin',
          actorName: data.actorName || 'সিস্টেম এডমিন',
          actorEmail: data.actorEmail,
          action: data.action || 'ADMIN_ACTION',
          category: data.category || 'SYSTEM',
          targetId: data.targetId || 'system',
          details: data.details || data.errorDetails || '',
          ipAddress: data.ipAddress,
          changesPayload: data.changesPayload,
          status: data.status || 'SUCCESS'
        });
      });
      logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      callback(logs);
    }, (error) => {
      console.warn('Audit log subscription warning:', error);
    });
  } catch (error) {
    console.warn('Audit log subscription failed:', error);
    return () => {};
  }
}

