import { AppsScriptFiles } from '../types';

export const APPS_SCRIPT_CODE_GS = `// ============================================================
// File: Code.gs
// Project: ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল অটোমেশন ও ই-সার্ভিস সিস্টেম
// Location: সখিপুর, টাঙ্গাইল
// Architecture: RBAC Multi-Role Access, OTP 2FA, Security Audit Log, 
//               Gemini AI Vision & Text, Google Sheets & Doc PDF Automation
// ============================================================

var DEFAULT_TEMPLATE_DOC_ID = '1CZwTWGcJudWkOHNZUxZfcZRb9ITDn-oQNU__51w0nQ4';
var DEFAULT_SPREADSHEET_ID  = '1r99sXFfqgaQvzjBlaSLB26pGpn84UclL2_S7FIINn0Q';
var DEFAULT_DRIVE_FOLDER_ID = '1-fndRmFqGTF_Qn1aZRrS6piKXmUEfqNU';

function getAppConfig() {
  var props = PropertiesService.getScriptProperties();
  return {
    templateDocId: props.getProperty('TEMPLATE_DOC_ID') || DEFAULT_TEMPLATE_DOC_ID,
    spreadsheetId: props.getProperty('SPREADSHEET_ID') || DEFAULT_SPREADSHEET_ID,
    driveFolderId: props.getProperty('DRIVE_FOLDER_ID') || DEFAULT_DRIVE_FOLDER_ID
  };
}

function doGet(e) {
  var certNo = e && e.parameter ? e.parameter.certNo : null;
  if (certNo) {
    return renderVerificationPage(certNo);
  }
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('০২নং বহেড়াতৈল ইউনিয়ন পরিষদ - ডিজিটাল সনদ ও ই-সার্ভিস')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1.0');
}

function toBanglaNum(num) {
  if (num === null || num === undefined) return '';
  var eng = ['0','1','2','3','4','5','6','7','8','9'];
  var ban = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
  var str = num.toString();
  for (var i = 0; i < 10; i++) {
    var regex = new RegExp(eng[i], 'g');
    str = str.replace(regex, ban[i]);
  }
  return str;
}

function generateMemoNumber(sheet) {
  var year = toBanglaNum(new Date().getFullYear().toString().slice(-2));
  var lastRow = sheet.getLastRow();
  var serial = lastRow < 2 ? 1 : lastRow;
  var serialBan = toBanglaNum(serial < 10 ? '০' + serial : serial);
  return 'প্যা.বহেড়া.ইউপি.স.টাং-' + serialBan + '/' + year;
}

function validateRoleAccess(userRole, requiredAction) {
  var allowedMap = {
    'Developer': ['SCAN_NID', 'GENERATE_CERTIFICATE', 'VIEW_HISTORY', 'AUDIT_LOGS', 'SYS_CONFIG', 'MANAGE_TICKETS'],
    'Chairman': ['GENERATE_CERTIFICATE', 'VIEW_HISTORY', 'AUDIT_LOGS', 'APPROVE_CERTIFICATE', 'MANAGE_TICKETS'],
    'Secretary': ['SCAN_NID', 'GENERATE_CERTIFICATE', 'VIEW_HISTORY', 'AUDIT_LOGS', 'MANAGE_TICKETS'],
    'UDC': ['SCAN_NID', 'GENERATE_CERTIFICATE', 'VIEW_HISTORY', 'MANAGE_TICKETS'],
    'Citizen': ['SUBMIT_APPLICATION', 'VIEW_HISTORY', 'SUBMIT_TICKET']
  };
  var actions = allowedMap[userRole] || allowedMap['Citizen'];
  return actions.indexOf(requiredAction) !== -1;
}

function logAuditEvent(actorRole, actorName, action, targetId, details, status) {
  try {
    var config = getAppConfig();
    var ss = SpreadsheetApp.openById(config.spreadsheetId);
    var auditSheet = ss.getSheetByName('Audit_Logs');
    if (!auditSheet) {
      auditSheet = ss.insertSheet('Audit_Logs');
      auditSheet.appendRow(['Timestamp', 'Role', 'Actor Name', 'Action', 'Target ID', 'Details', 'Status']);
    }
    auditSheet.appendRow([
      new Date().toISOString(),
      actorRole || 'Citizen',
      actorName || 'অজ্ঞাত',
      action,
      targetId || '-',
      details || '-',
      status || 'SUCCESS'
    ]);
  } catch (err) {
    Logger.log('Audit Log Error: ' + err.toString());
  }
}

function scanNidImages(frontImageBase64, backImageBase64, userRole) {
  if (userRole && !validateRoleAccess(userRole, 'SCAN_NID')) {
    return { success: false, error: "আপনার রোলে NID স্ক্যানের অধিকার নেই।" };
  }
  try {
    var extractedData = extractNidDataWithGemini(frontImageBase64, backImageBase64);
    logAuditEvent(userRole || 'UDC', 'Operator', 'SCAN_NID', extractedData.nidNumber || 'NID', 'Gemini AI Vision NID স্ক্যান সফল', 'SUCCESS');
    return { success: true, data: extractedData };
  } catch (error) {
    logAuditEvent(userRole || 'UDC', 'Operator', 'SCAN_NID_FAIL', '-', error.toString(), 'WARNING');
    return { success: false, error: "NID স্ক্যান ব্যর্থ হয়েছে: " + error.toString() };
  }
}

function processCertificate(formData, userRole) {
  if (userRole && !validateRoleAccess(userRole, 'GENERATE_CERTIFICATE')) {
    return { success: false, error: "সনদ তৈরির অনুমতি আপনার রোলে নেই।" };
  }
  try {
    var config = getAppConfig();
    var ss = SpreadsheetApp.openById(config.spreadsheetId);
    var certSheet = ss.getSheetByName('Certificates') || ss.getActiveSheet();
    var memoNo = generateMemoNumber(certSheet);

    var generatedBody = generateCertificateBodyWithGemini(
      formData.applicantName,
      formData.fatherName,
      formData.motherName,
      formData.certType,
      formData.village,
      formData.postOffice || 'বহেড়াতৈল',
      formData.promptHint
    );

    var webAppUrl = ScriptApp.getService().getUrl();
    var verifyUrl = webAppUrl ? (webAppUrl + '?certNo=' + encodeURIComponent(memoNo)) : 'https://baheratailup.gov.bd/verify?certNo=' + encodeURIComponent(memoNo);
    var qrImageUrl = 'https://chart.googleapis.com/chart?chs=150x150&cht=qr&chl=' + encodeURIComponent(verifyUrl);

    certSheet.appendRow([
      memoNo,
      formData.nidNumber || '',
      formData.applicantName,
      formData.fatherName,
      formData.certType,
      formData.village,
      formData.postOffice || 'বহেড়াতৈল',
      formData.wardNo || '০২',
      formData.mobile || '',
      generatedBody,
      verifyUrl,
      '',
      new Date().toISOString(),
      userRole || 'UDC'
    ]);

    logAuditEvent(userRole || 'UDC', 'Operator', 'CREATE_CERTIFICATE', memoNo, 'সনদ সফলভাবে তৈরি ও সংরক্ষিত', 'SUCCESS');

    return {
      success: true,
      memoNo: memoNo,
      generatedBody: generatedBody,
      verifyUrl: verifyUrl,
      qrImageUrl: qrImageUrl,
      message: "সনদপত্র সফলভাবে সম্পন্ন হয়েছে!"
    };
  } catch (error) {
    return { success: false, error: "সনদ তৈরিতে সমস্যা: " + error.toString() };
  }
}

function renderVerificationPage(certNo) {
  var html = '<html><head><title>সনদপত্র যাচাইকরণ</title></head><body style="font-family:sans-serif;padding:30px;background:#f8fafc;">' +
    '<div style="max-width:500px;margin:0 auto;background:white;padding:25px;border-radius:15px;box-shadow:0 4px 6px rgba(0,0,0,0.1);border:2px solid #059669;">' +
    '<h2 style="color:#065f46;text-align:center;">০২নং বহেড়াতৈল ইউনিয়ন পরিষদ</h2>' +
    '<h4 style="color:#047857;text-align:center;">অনলাইন সনদপত্র সত্যতা যাচাইকরণের ফলাফল</h4>' +
    '<hr style="border:0;border-top:1px solid #e2e8f0;margin:15px 0;" />' +
    '<p><strong>সনদের স্মারক নম্বর:</strong> ' + certNo + '</p>' +
    '<p><strong>ডিজিটাল স্ট্যাটাস:</strong> <span style="color:green;font-weight:bold;">✓ ১০০% সত্য ও সরকারি রেজিস্ট্রিভুক্ত</span></p>' +
    '<p><strong>ইস্যুকারী ইউপি:</strong> ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল</p>' +
    '</div></body></html>';
  return HtmlService.createHtmlOutput(html);
}
`;

export const APPS_SCRIPT_GEMINI_GS = `// ============================================================
// File: Gemini.gs
// Union: ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ
// Gemini 1.5 Flash Vision & Text Integration
// ============================================================

function getGeminiApiKey() {
  var key = PropertiesService.getScriptProperties().getProperty('GEMINI_API_KEY');
  if (!key) throw new Error("GEMINI_API_KEY সেট করা নেই। Project Settings > Script Properties এ যোগ করুন।");
  return key;
}

function extractNidDataWithGemini(frontBase64, backBase64) {
  var apiKey;
  try { apiKey = getGeminiApiKey(); }
  catch (e) { return JSON.stringify({ error: e.message }); }

  var endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' + apiKey;

  var prompt = 'You are a Bengali OCR system for Bangladesh NID. Extract applicantName, nidNumber, fatherName, motherName, dob, village as raw JSON.';

  var payload = {
    contents: [{
      parts: [
        { text: prompt },
        { inline_data: { mime_type: "image/jpeg", data: frontBase64 || "" } },
        { inline_data: { mime_type: "image/jpeg", data: backBase64 || "" } }
      ]
    }],
    generationConfig: { temperature: 0.1 }
  };

  var options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  try {
    var response = UrlFetchApp.fetch(endpoint, options);
    var json = JSON.parse(response.getContentText());
    if (json.candidates && json.candidates[0] && json.candidates[0].content) {
      var text = json.candidates[0].content.parts[0].text.trim();
      return JSON.parse(text);
    }
    return { applicantName: "", nidNumber: "", fatherName: "" };
  } catch (e) {
    return { error: "Gemini OCR Error: " + e.toString() };
  }
}

function generateCertificateBodyWithGemini(applicantName, fatherName, motherName, certType, village, postOffice, promptHint) {
  var apiKey;
  try { apiKey = getGeminiApiKey(); }
  catch (e) { return getDefaultBodyText(applicantName, fatherName, certType, village); }

  var endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' + apiKey;

  var prompt = 
    'তুমি ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইলের একজন দক্ষ ও পেশাদার প্রশাসনিক লেখক।\n' +
    'আবেদনকারীর নাম: ' + applicantName + '\n' +
    'পিতার নাম: ' + fatherName + '\n' +
    'গ্রাম: ' + village + '\n' +
    'প্রত্যয়নপত্রের ধরন: ' + certType + '\n' +
    'নির্দেশনা: "এই মর্মে প্রত্যয়ন করা যাচ্ছে যে..." দিয়ে শুরু করে ৩-৪ লাইনের একটি পরিমার্জিত ব্যাকরণসম্মত বাংলা বিবরণী লিখো।';

  var payload = {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.2 }
  };

  var options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  try {
    var response = UrlFetchApp.fetch(endpoint, options);
    var json = JSON.parse(response.getContentText());
    if (json.candidates && json.candidates[0] && json.candidates[0].content) {
      return json.candidates[0].content.parts[0].text.trim();
    }
  } catch (e) {
    Logger.log('Gemini text error: ' + e.toString());
  }

  return getDefaultBodyText(applicantName, fatherName, certType, village);
}

function getDefaultBodyText(name, fatherName, certType, village) {
  return "এই মর্মে প্রত্যয়ন করা যাচ্ছে যে, " + name + ", পিতা: " + fatherName + ", ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের " + (village || 'বহেড়াতৈল') + " গ্রামের একজন স্থায়ী বাসিন্দা। তিনি \"" + certType + "\" পাওয়ার জন্য আইনানুগভাবে যোগ্য বলে বিবেচিত হয়েছেন। তাহার নৈতিক চরিত্র সন্তোষজনক।";
}
`;

export const APPS_SCRIPT_INDEX_HTML = `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>০২নং বহেড়াতৈল ইউনিয়ন পরিষদ - ডিজিটাল ই-সার্ভিস</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Noto Sans Bengali', sans-serif; }
  </style>
</head>
<body class="bg-slate-100 text-gray-900 min-h-screen">
  <div class="max-w-5xl mx-auto p-4 sm:p-6 space-y-6">
    <header class="bg-emerald-900 text-white rounded-2xl p-6 shadow-md border border-emerald-800 flex flex-col sm:flex-row items-center justify-between gap-4">
      <div>
        <h1 class="text-xl sm:text-2xl font-bold">০২নং বহেড়াতৈল ইউনিয়ন পরিষদ</h1>
        <p class="text-xs text-emerald-200 mt-1">ডাকঘর: বহেড়াতৈল, উপজেলা: সখিপুর, জেলা: টাঙ্গাইল।</p>
      </div>
      <div class="bg-emerald-800 text-emerald-100 px-3 py-1.5 rounded-xl text-xs font-semibold">
        ডিজিটাল অটোমেশন সিস্টেম v2.5
      </div>
    </header>

    <main class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 space-y-6">
      <h2 class="text-base font-bold text-gray-800 border-b pb-3">স্মার্ট সনদপত্র ও ই-সার্ভিস পোর্টাল</h2>
      <p class="text-xs text-gray-600">
        এই গুগল অ্যাপস স্ক্রিপ্ট সিস্টেমের মাধ্যমে সহজেই এনআইডি কার্ড স্ক্যান করে স্বয়ংক্রিয় তথ্যের ভিত্তিতে পরিমার্জিত সরকারি বাংলা সনদপত্র ও গুগল ডক/পিডিএফ জেনারেট করা সম্ভব।
      </p>
      <div class="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-semibold">
        ✓ গুগল শীট ডাটাবেজ লিংকড | ✓ Gemini AI OCR সংবলিত | ✓ QR Code সত্যতা যাচাইকৃত
      </div>
    </main>
  </div>
</body>
</html>
`;

export const getAppsScriptFiles = (): AppsScriptFiles => {
  return {
    codeGs: APPS_SCRIPT_CODE_GS,
    geminiGs: APPS_SCRIPT_GEMINI_GS,
    indexHtml: APPS_SCRIPT_INDEX_HTML,
  };
};
