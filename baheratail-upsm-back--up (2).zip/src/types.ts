export interface SimpleFieldConfig {
  key: string;
  label: string;
  placeholder?: string;
  type?: 'text' | 'number' | 'date';
  required?: boolean;
}

export interface TableConfig {
  key: string;
  title: string;
  headers: string[];
}

export interface CertificateTypeConfig {
  key: string;
  label: string;
  category: string;
  iconName?: string;
  simpleFields?: SimpleFieldConfig[];
  tables?: TableConfig[];
  promptInstruction?: string;
}

export interface CitizenData {
  nid?: string;
  birthNo?: string;
  name: string;
  father: string;
  spouseName?: string;
  mother: string;
  gender: 'পুরুষ' | 'মহিলা' | 'হিজরা';
  mobile?: string;
  village: string;
  postOffice: string;
  postCode?: string;
  wardNo: string;
  upName?: string;
  district?: string;
  upazila?: string;
}

export interface TableRowData {
  [colIndex: number]: string;
}

export interface CertificateExtraData {
  simpleFields: Record<string, string>;
  tables: Record<string, string[][]>;
}

export interface CertificateRecord {
  id: string;
  memoNo: string;
  issueDate: string;
  issueDateEn: string;
  typeKey: string;
  typeLabel: string;
  category: string;
  citizen: CitizenData;
  extra: CertificateExtraData;
  bodyText: string;
  qrCodeUrl?: string;
  verificationUrl: string;
  status: 'pending_approval' | 'approved' | 'issued' | 'revoked' | 'cancelled' | 'draft';
  issuedBy: string;
  approvedBy?: string;
  approvedAt?: string;
  cancelledBy?: string;
  cancelledAt?: string;
  rejectionReason?: string;
  createdAt: string;
  feeAmount?: number;
  paymentMethod?: 'bKash' | 'Nagad' | 'Rocket' | 'Cash' | 'Upay';
  trxId?: string;
  paymentStatus?: 'paid' | 'unpaid' | 'waived';
}

export interface CouncilMember {
  id: string;
  category: 'chairman' | 'reserved_female' | 'general_member' | 'officer' | 'udc' | 'dafadar' | 'gram_police';
  name: string;
  designation: string;
  mobile: string;
  wardNo?: string;
  photoUrl?: string;
  isAutoSynced?: boolean;
}

export interface UnionParishadConfig {
  upName: string;
  upNameEn: string;
  upazila: string;
  district: string;
  address: string;
  phone?: string;
  email?: string;
  chairmanName: string;
  chairmanTitle: string;
  chairmanPhone?: string;
  chairmanSignatureUrl?: string;
  secretaryName: string;
  secretaryTitle: string;
  secretaryPhone?: string;
  secretarySignatureUrl?: string;
  enableDigitalSignature?: boolean;
  showSecretarySignature?: boolean;
  logoUrl: string;
  sealText: string;
  defaultPromptPrefix: string;
  enableHeaderInPrint: boolean;
  watermarkOpacity: number;
  certificateFeeDefault?: number;
  categoryFees?: Record<string, number>;
  typeFeeOverrides?: Record<string, number>;
  // MFS Payment Details
  paymentBkashNumber?: string;
  paymentNagadNumber?: string;
  paymentRocketNumber?: string;
  paymentInstructions?: string;
  // Template Customizer Options
  templateHeaderStyle?: 'tri-column' | 'classic' | 'centered';
  bodyFontSize?: number;
  borderStyle?: 'double-green-red' | 'double-green' | 'single-green' | 'none';
  blankSealSize?: number; // Circle diameter in px (0 to hide)
  qrCodePosition?: 'left-bottom' | 'right-bottom';
  templateDocId: string;
  targetFolderId: string;
  sheetId: string;
  appsScriptUrl?: string;
  r2AccountId?: string;
  r2AccessKeyId?: string;
  r2SecretAccessKey?: string;
  r2Endpoint?: string;
  r2BucketName?: string;
  geminiApiKey?: string;
  // Developer & Backup URLs
  developerName?: string;
  developerTitle?: string;
  developerPhotoUrl?: string;
  developerBio?: string;
  developerEmail?: string;
  developerPhone?: string;
  developerWhatsappNumber?: string;
  developerFacebookUrl?: string;
  developerLinkedinUrl?: string;
  githubRepoUrl?: string;
  githubBranch?: string;
  googleDriveBackupUrl?: string;
  archiveFolderId?: string;
  mcpEndpointUrl?: string;
  webhookUrl?: string;
  webhookSecret?: string;
  lastBackupDate?: string;
  councilMembers?: CouncilMember[];
  pluginsConfig?: {
    smsNotification?: boolean;
    gdriveAutoSync?: boolean;
    geminiOcrVision?: boolean;
    auditTrailLog?: boolean;
    webhookIntegration?: boolean;
    mcpProtocolAgent?: boolean;
  };
}

export interface ApiKeyRecord {
  id: string;
  name: string;
  key: string;
  permissions: 'read' | 'write' | 'admin';
  createdAt: string;
  lastUsedAt?: string;
  status: 'active' | 'revoked';
}

export interface WebhookConfig {
  id: string;
  name: string;
  url: string;
  secret?: string;
  events: ('certificate.created' | 'certificate.approved' | 'certificate.cancelled' | 'citizen.registered')[];
  enabled: boolean;
  createdAt: string;
}

export interface WebhookLogRecord {
  id: string;
  webhookName: string;
  url: string;
  event: string;
  payloadSummary: string;
  status: 'success' | 'failed';
  httpStatus: number;
  timestamp: string;
  error?: string;
}

export interface CitizenAccountRecord {
  id: string;
  nid?: string;
  birthNo?: string;
  name: string;
  father: string;
  mother: string;
  spouseName?: string;
  gender: 'পুরুষ' | 'মহিলা' | 'হিজরা';
  mobile?: string;
  village: string;
  wardNo: string;
  postOffice: string;
  postCode?: string;
  totalCertificates: number;
  lastCertificateType?: string;
  lastCertificateDate?: string;
  registeredAt: string;
}

export interface NidScanResult {
  nidNo?: string;
  name?: string;
  fatherName?: string;
  motherName?: string;
  spouseName?: string;
  dob?: string;
  addressText?: string;
  village?: string;
  wardNo?: string;
  rawText?: string;
  error?: string;
}

export interface VerificationResult {
  found: boolean;
  certificate?: CertificateRecord;
  verifiedAt: string;
  message?: string;
}

export interface BackupSnapshot {
  id: string;
  filename: string;
  timestamp: string;
  archiveFolderId: string;
  sheetId: string;
  recordsCount: number;
  sizeKb?: number;
  status: 'completed' | 'in_progress' | 'failed';
  downloadUrl?: string;
  driveFileId?: string;
  notes?: string;
}

export type CertificateType =
  | 'নাগরিকত্ব সনদ'
  | 'চারিত্রিক সনদ'
  | 'পরিচয়পত্র ও প্রত্যয়নপত্র'
  | 'ভূমিহীন প্রত্যয়নপত্র'
  | 'বাৎসরিক আয় সনদ'
  | 'পুনর্বিবাহ না হওয়ার সনদ'
  | 'অবিবাহিত সনদ'
  | 'মৃত ব্যক্তির ওয়ারিশান বিবরণী'
  | 'অভিভাবকের সম্মতিপত্র'
  | 'বংশগত পরিচয় সনদ';

export interface CertificateFormData {
  applicantName: string;
  applicantNameEng?: string;
  fatherName: string;
  motherName: string;
  spouseName?: string;
  nidNumber: string;
  dob: string;
  village: string;
  postOffice: string;
  wardNo: string;
  certType: CertificateType;
  promptHint?: string;
  issueDate: string;
  memoNo: string;
}

export interface GeneratedCertificateRecord extends CertificateFormData {
  id: string;
  createdAt: string;
  certificateBody: string;
  chairmanName: string;
  unionName: string;
  status?: 'খসড়া' | 'অনুমোদিত' | 'বাতিল' | 'যাচাইকৃত';
  approvedBy?: string;
  translatedBodyEng?: string;
}

export interface AppsScriptFiles {
  codeGs: string;
  geminiGs: string;
  indexHtml: string;
}

export type UserRole = 'super_admin' | 'Developer' | 'UDC' | 'Secretary' | 'Chairman' | 'Citizen';

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  role: UserRole;
  isOtpVerified: boolean;
  wardNo?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actorRole: UserRole;
  actorName: string;
  actorEmail?: string;
  action: string;
  category?: 'CONFIG' | 'USER_MANAGEMENT' | 'CERTIFICATE' | 'SYSTEM' | 'SECURITY';
  targetId: string;
  details: string;
  ipAddress?: string;
  changesPayload?: string;
  status: 'SUCCESS' | 'WARNING' | 'DENIED';
}

export interface SupportTicket {
  id: string;
  citizenName: string;
  phone: string;
  nidNumber: string;
  subject: string;
  description: string;
  category: 'সনদ সংশোধন' | 'স্ট্যাটাস চেক' | 'কারিগরি সমস্যা' | 'সাধারণ অনুসন্ধান';
  status: 'নতুন' | 'প্রক্রিয়াধীন' | 'নিষ্পন্ন';
  priority: 'জরুরি' | 'সাধারণ' | 'কম';
  aiSuggestedReply?: string;
  createdAt: string;
}

export interface SecurityRiskCheckResult {
  riskScore: number; // 0 to 100
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  warnings: string[];
  recommendations: string[];
}

export interface AiAnalyticsForecast {
  totalCertificatesThisMonth: number;
  projectedNextMonth: number;
  peakWards: { wardNo: string; count: number }[];
  popularTypes: { type: string; percentage: number }[];
  aiForecastSummary: string;
  resourceOptimizationTips: string[];
}

export interface NidExtractedData {
  nidNumber?: string;
  applicantName?: string;
  applicantNameEng?: string;
  fatherName?: string;
  motherName?: string;
  spouseName?: string;
  dob?: string;
  village?: string;
  postOffice?: string;
  upazila?: string;
  district?: string;
  addressText?: string;
  gender?: string;
  bloodGroup?: string;
  rawText?: string;
  error?: string;
}


